import { useEffect, useRef } from 'react';
import { AppState, PanResponder } from 'react-native';

const INACTIVITY_TIMEOUT = 2 * 60 * 1000; // 2 minutes

export const useInactivityLogout = (isAuthenticated, logout) => {
  const inactivityTimer = useRef(null);
  const appState = useRef(AppState.currentState);

  const resetInactivityTimer = () => {
    if (inactivityTimer.current) {
      clearTimeout(inactivityTimer.current);
    }

    if (isAuthenticated) {
      inactivityTimer.current = setTimeout(() => {
        console.log('User inactive for 2 minutes, logging out...');
        logout();
      }, INACTIVITY_TIMEOUT);
    }
  };

  useEffect(() => {
    if (!isAuthenticated) {
      if (inactivityTimer.current) {
        clearTimeout(inactivityTimer.current);
      }
      return;
    }

    resetInactivityTimer();

    const subscription = AppState.addEventListener('change', (nextAppState) => {
      if (
        appState.current.match(/inactive|background/) &&
        nextAppState === 'active'
      ) {
        resetInactivityTimer();
      }
      appState.current = nextAppState;
    });

    return () => {
      if (inactivityTimer.current) {
        clearTimeout(inactivityTimer.current);
      }
      subscription.remove();
    };
  }, [isAuthenticated]);

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponderCapture: () => {
        resetInactivityTimer();
        return false;
      },
      onMoveShouldSetPanResponderCapture: () => {
        resetInactivityTimer();
        return false;
      },
    })
  ).current;

  return panResponder;
};
