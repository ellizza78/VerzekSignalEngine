import { useState, useEffect } from 'react';
import * as Updates from 'expo-updates';
import * as Application from 'expo-application';
import Constants from 'expo-constants';
import { Alert, Platform } from 'react-native';

export const useAppUpdates = (remoteConfig) => {
  const [updateAvailable, setUpdateAvailable] = useState(false);
  const [forceUpdate, setForceUpdate] = useState(false);
  const [checking, setChecking] = useState(false);

  useEffect(() => {
    if (remoteConfig) {
      checkForUpdates();
    }
  }, [remoteConfig]);

  const checkForUpdates = async () => {
    try {
      setChecking(true);
      
      // Reset force update state to reflect current config
      setForceUpdate(false);

      // Get current version with proper fallbacks for dev vs production
      const currentVersion = getCurrentVersion();
      const minRequiredVersion = remoteConfig?.appVersionMin || '0.0.0';

      console.log(`📱 Version check: current=${currentVersion}, required=${minRequiredVersion}, force=${remoteConfig?.forceUpdate}`);

      // Log warning if version detection failed
      if (currentVersion === '0.0.0') {
        console.warn('⚠️ Could not detect app version - force update checks disabled');
      }

      // 1. Try OTA update first (might fix the issue without store update)
      let otaUpdateAvailable = false;
      if (!__DEV__ && Updates.isEnabled) {
        try {
          const update = await Updates.checkForUpdateAsync();
          
          if (update.isAvailable) {
            console.log('📦 OTA update available, downloading...');
            setUpdateAvailable(true);
            
            // Try to download the OTA update
            try {
              await Updates.fetchUpdateAsync();
              
              // Mark OTA as available ONLY after successful download
              otaUpdateAvailable = true;
              
              Alert.alert(
                'Update Downloaded',
                'A new version has been downloaded. Restart the app to apply changes.',
                [
                  { text: 'Later', style: 'cancel' },
                  { 
                    text: 'Restart Now', 
                    onPress: async () => {
                      await Updates.reloadAsync();
                    }
                  }
                ]
              );
            } catch (fetchError) {
              console.error('❌ OTA download failed:', fetchError);
              setUpdateAvailable(false);
              // otaUpdateAvailable remains false, so force update check will run
            }
          } else {
            console.log('✅ App is up to date (OTA)');
          }
        } catch (error) {
          console.warn('⚠️ OTA update check failed:', error);
          // otaUpdateAvailable remains false, so force update check will run
        }
      }

      // 2. Check for force update (after trying OTA)
      // Only block if no OTA update can fix it
      if (!otaUpdateAvailable) {
        // Check force update flag
        if (remoteConfig?.forceUpdate === true) {
          console.log('⚠️ Force update flag enabled in remote config');
          setForceUpdate(true);
          return;
        }

        // Check version requirement (only if we have valid versions)
        if (currentVersion !== '0.0.0' && 
            minRequiredVersion !== '0.0.0' && 
            compareVersions(currentVersion, minRequiredVersion) < 0) {
          console.log(`⚠️ Force update required: ${currentVersion} < ${minRequiredVersion}`);
          setForceUpdate(true);
          return;
        }
      }
    } catch (error) {
      console.error('Error checking for updates:', error);
    } finally {
      setChecking(false);
    }
  };

  const manualCheckUpdate = async () => {
    await checkForUpdates();
  };

  return {
    updateAvailable,
    forceUpdate,
    checking,
    checkForUpdates: manualCheckUpdate,
  };
};

// Get current version with proper fallbacks for dev vs production
function getCurrentVersion() {
  // Priority 1: Native version (works in standalone/production builds)
  if (Application.nativeApplicationVersion) {
    return Application.nativeApplicationVersion;
  }
  
  // Priority 2: Manifest version (works in some OTA scenarios)
  if (Updates.manifest?.version) {
    return Updates.manifest.version;
  }
  
  // Priority 3: Constants version (works in Expo Go/dev)
  if (Constants.manifest?.version) {
    return Constants.manifest.version;
  }
  
  // Priority 4: expo-constants expoConfig (works in some dev scenarios)
  if (Constants.expoConfig?.version) {
    return Constants.expoConfig.version;
  }
  
  // Fallback: Return '0.0.0' to disable version-based force updates
  // This prevents false positives but allows force update flag to work
  console.warn('⚠️ Could not detect app version from any source');
  return '0.0.0';
}

// Compare semantic versions (returns -1 if v1 < v2, 0 if equal, 1 if v1 > v2)
function compareVersions(v1, v2) {
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);

  for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
    const p1 = parts1[i] || 0;
    const p2 = parts2[i] || 0;

    if (p1 < p2) return -1;
    if (p1 > p2) return 1;
  }

  return 0;
}
