import React, { createContext, useState, useEffect, useContext } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { authAPI } from '../services/api';

const AuthContext = createContext({});

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Load user from storage on app start
  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const userData = await AsyncStorage.getItem('user');
      const accessToken = await AsyncStorage.getItem('access_token');

      if (userData && accessToken) {
        const user = JSON.parse(userData);
        setUser(user);
        
        // SECURITY: Only auto-login if email is verified
        // Unverified users need to verify email first
        if (user.email_verified) {
          setIsAuthenticated(true);
        } else {
          // Keep user data (for EmailVerificationScreen) but don't authenticate
          setIsAuthenticated(false);
          console.log('User email not verified - redirecting to verification');
        }
      }
    } catch (error) {
      console.error('Error loading user:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadRememberedCredentials = async () => {
    try {
      const savedEmail = await SecureStore.getItemAsync('remembered_email');
      return { email: savedEmail, password: null };
    } catch (error) {
      console.error('Error loading remembered credentials:', error);
      return { email: null, password: null };
    }
  };

  const login = async (email, password, rememberMe = false) => {
    try {
      const response = await authAPI.login(email, password, null, null);
      const { user: userData, access_token, refresh_token } = response.data;

      // Save to storage
      await AsyncStorage.multiSet([
        ['user', JSON.stringify(userData)],
        ['access_token', access_token],
        ['refresh_token', refresh_token],
      ]);

      // Handle Remember Me - Store only email (NEVER store passwords for security)
      if (rememberMe) {
        await SecureStore.setItemAsync('remembered_email', email);
      } else {
        await SecureStore.deleteItemAsync('remembered_email');
      }

      setUser(userData);
      setIsAuthenticated(true);

      return { success: true };
    } catch (error) {
      // Check if error is due to unverified email (403 with email_verified: false)
      const errorData = error.response?.data;
      if (error.response?.status === 403 && errorData?.email_verified === false) {
        return {
          success: false,
          emailVerificationRequired: true,
          email: errorData.email,
          user_id: errorData.user_id,
          error: errorData.message || 'Please verify your email address before logging in',
        };
      }

      return {
        success: false,
        error: errorData?.error || 'Login failed',
      };
    }
  };

  const register = async (email, password, fullName, username, referralCode = null) => {
    try {
      const response = await authAPI.register(email, password, fullName, username, null, null, referralCode);
      const { user: userData, access_token, refresh_token, verification_sent } = response.data;

      // Save to storage (but don't auto-login yet - need email verification)
      await AsyncStorage.multiSet([
        ['user', JSON.stringify(userData)],
        ['access_token', access_token],
        ['refresh_token', refresh_token],
      ]);

      setUser(userData);
      // Don't set isAuthenticated yet - require email verification first
      setIsAuthenticated(false);

      return { 
        success: true, 
        emailVerificationRequired: !userData.email_verified,
        verification_sent,
        email: userData.email 
      };
    } catch (error) {
      return {
        success: false,
        error: error.response?.data?.error || 'Registration failed',
      };
    }
  };

  const logout = async () => {
    try {
      // Keep remembered credentials on logout
      await AsyncStorage.multiRemove(['user', 'access_token', 'refresh_token']);
      setUser(null);
      setIsAuthenticated(false);
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const refreshUser = async () => {
    try {
      const response = await authAPI.getCurrentUser();
      const userData = response.data.user;

      await AsyncStorage.setItem('user', JSON.stringify(userData));
      setUser(userData);
    } catch (error) {
      console.error('Error refreshing user:', error);
    }
  };

  const checkVerificationStatus = async () => {
    try {
      const response = await authAPI.checkVerification();
      const { email_verified } = response.data;

      if (email_verified && user) {
        // Update user data with verified status
        const updatedUser = { ...user, email_verified: true };
        await AsyncStorage.setItem('user', JSON.stringify(updatedUser));
        setUser(updatedUser);
        
        // SECURITY: Now that email is verified, authenticate the user
        setIsAuthenticated(true);
        console.log('Email verified - user authenticated');
      }

      return email_verified;
    } catch (error) {
      console.error('Error checking verification:', error);
      return false;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated,
        loading,
        login,
        register,
        logout,
        refreshUser,
        checkVerificationStatus,
        loadRememberedCredentials,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
