import React, { createContext, useState, useEffect, useContext } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { API_BASE_URL } from '../config/api';

const RemoteConfigContext = createContext({});

// Default fallback config (used if API fails)
const DEFAULT_CONFIG = {
  version: '1.1.3',
  appVersionMin: '1.1.0',
  forceUpdate: false,
  featureFlags: {
    autoTrade: true,
    realtimeSignals: true,
    emailVerification: false,
    telegramIntegration: true,
    multiExchange: true,
    dcaEngine: true,
    aiAssistant: false,
    pushNotifications: false,
    websocketPrices: false,
    socialTrading: false,
    advancedCharting: false,
  },
  serviceEndpoints: {
    apiBaseUrl: API_BASE_URL,
    websocketUrl: `wss://${API_BASE_URL.replace('https://', '')}`,
    signalsUrl: `${API_BASE_URL}/api/signals`,
    pricesFeedUrl: `${API_BASE_URL}/api/prices/realtime`,
  },
  uiMessages: {
    welcome: 'Welcome to Verzek AutoTrader!',
    maintenance: false,
    maintenanceMessage: '',
    banner: '',
    announcement: '',
  },
  tradingLimits: {
    maxPositionsPerUser: 50,
    minOrderSize: 10,
    maxOrderSize: 10000,
    maxLeverage: 20,
    defaultLeverage: 5,
  },
};

export const RemoteConfigProvider = ({ children }) => {
  const [config, setConfig] = useState(DEFAULT_CONFIG);
  const [loading, setLoading] = useState(true);
  const [lastFetched, setLastFetched] = useState(null);

  // Fetch remote config on mount and every 5 minutes
  useEffect(() => {
    fetchConfig();
    
    // Refresh config every 5 minutes
    const interval = setInterval(() => {
      fetchConfig(true); // Silent refresh
    }, 5 * 60 * 1000);

    return () => clearInterval(interval);
  }, []);

  const fetchConfig = async (silent = false) => {
    try {
      if (!silent) setLoading(true);

      // Try to fetch from API
      const response = await axios.get(`${API_BASE_URL}/api/app-config`, {
        timeout: 10000,
        headers: {
          'Cache-Control': 'no-cache',
        },
      });

      if (response.data) {
        const newConfig = { ...DEFAULT_CONFIG, ...response.data };
        setConfig(newConfig);
        setLastFetched(new Date().toISOString());

        // Cache config locally
        await AsyncStorage.setItem('cached_remote_config', JSON.stringify(newConfig));
        await AsyncStorage.setItem('config_last_fetched', new Date().toISOString());

        console.log('✅ Remote config loaded:', newConfig._metadata?.configVersion || 'unknown');
      }
    } catch (error) {
      console.warn('⚠️ Failed to fetch remote config, using cached/default:', error.message);

      // Try to load cached config
      try {
        const cachedConfig = await AsyncStorage.getItem('cached_remote_config');
        if (cachedConfig) {
          setConfig(JSON.parse(cachedConfig));
          const cachedTime = await AsyncStorage.getItem('config_last_fetched');
          setLastFetched(cachedTime);
          console.log('📦 Using cached remote config');
        }
      } catch (cacheError) {
        console.warn('Using default config');
      }
    } finally {
      setLoading(false);
    }
  };

  const refreshConfig = async () => {
    await fetchConfig(false);
  };

  const isFeatureEnabled = (featureName) => {
    return config?.featureFlags?.[featureName] === true;
  };

  const getEndpoint = (endpointName) => {
    return config?.serviceEndpoints?.[endpointName] || '';
  };

  const getMessage = (messageName) => {
    return config?.uiMessages?.[messageName] || '';
  };

  const getTradingLimit = (limitName) => {
    return config?.tradingLimits?.[limitName];
  };

  const value = {
    config,
    loading,
    lastFetched,
    refreshConfig,
    isFeatureEnabled,
    getEndpoint,
    getMessage,
    getTradingLimit,
  };

  return (
    <RemoteConfigContext.Provider value={value}>
      {children}
    </RemoteConfigContext.Provider>
  );
};

export const useRemoteConfig = () => {
  const context = useContext(RemoteConfigContext);
  if (!context) {
    throw new Error('useRemoteConfig must be used within RemoteConfigProvider');
  }
  return context;
};

export default RemoteConfigContext;
