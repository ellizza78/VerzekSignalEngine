import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  ActivityIndicator,
  Linking,
} from 'react-native';
import { COLORS } from '../constants/colors';
import api from '../services/api';

const SupportScreen = () => {
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSendMessage = async () => {
    if (!subject.trim() || !message.trim()) {
      Alert.alert('Missing Information', 'Please fill in both subject and message');
      return;
    }

    try {
      setLoading(true);
      const response = await api.post('/support/message', {
        subject: subject.trim(),
        message: message.trim(),
      });

      Alert.alert(
        'Success',
        response.data.message || 'Support message sent successfully!',
        [
          {
            text: 'OK',
            onPress: () => {
              setSubject('');
              setMessage('');
            },
          },
        ]
      );
    } catch (error) {
      Alert.alert(
        'Error',
        error.response?.data?.error || 'Failed to send message. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  const openEmail = () => {
    Linking.openURL('mailto:support@vezekinnovative.com');
  };

  const openTelegram = () => {
    Linking.openURL('https://t.me/VerzekSupportBot');
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>🆘 Support Center</Text>
        <Text style={styles.headerSubtitle}>We're here to help</Text>
      </View>

      {/* Quick Contact Options */}
      <View style={styles.quickContact}>
        <Text style={styles.sectionTitle}>Quick Contact</Text>
        
        <TouchableOpacity style={styles.contactButton} onPress={openEmail}>
          <Text style={styles.contactIcon}>📧</Text>
          <View style={styles.contactInfo}>
            <Text style={styles.contactLabel}>Email Us</Text>
            <Text style={styles.contactValue}>support@vezekinnovative.com</Text>
          </View>
        </TouchableOpacity>

        <TouchableOpacity style={styles.contactButton} onPress={openTelegram}>
          <Text style={styles.contactIcon}>💬</Text>
          <View style={styles.contactInfo}>
            <Text style={styles.contactLabel}>Telegram Bot</Text>
            <Text style={styles.contactValue}>@VerzekSupportBot</Text>
          </View>
        </TouchableOpacity>
      </View>

      {/* Support Form */}
      <View style={styles.formCard}>
        <Text style={styles.sectionTitle}>Send Message</Text>
        <Text style={styles.sectionSubtitle}>
          We typically respond within 24 hours
        </Text>

        <View style={styles.inputGroup}>
          <Text style={styles.inputLabel}>Subject</Text>
          <TextInput
            style={styles.input}
            placeholder="Brief description of your issue"
            placeholderTextColor="#666"
            value={subject}
            onChangeText={setSubject}
            editable={!loading}
          />
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.inputLabel}>Message</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            placeholder="Describe your issue in detail..."
            placeholderTextColor="#666"
            value={message}
            onChangeText={setMessage}
            multiline
            numberOfLines={6}
            textAlignVertical="top"
            editable={!loading}
          />
        </View>

        <TouchableOpacity
          style={[styles.sendButton, loading && styles.sendButtonDisabled]}
          onPress={handleSendMessage}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#0A4A5C" />
          ) : (
            <>
              <Text style={styles.sendButtonText}>Send Message</Text>
              <Text style={styles.sendButtonIcon}>📤</Text>
            </>
          )}
        </TouchableOpacity>
      </View>

      {/* Support Hours */}
      <View style={styles.infoCard}>
        <Text style={styles.infoTitle}>⏰ Support Hours</Text>
        <Text style={styles.infoText}>Monday - Friday: 9 AM - 6 PM UTC</Text>
        <Text style={styles.infoText}>Saturday: 10 AM - 4 PM UTC</Text>
        <Text style={styles.infoText}>Sunday: Closed</Text>
      </View>

      {/* What We Help With */}
      <View style={styles.infoCard}>
        <Text style={styles.infoTitle}>💡 What We Help With</Text>
        <Text style={styles.bulletPoint}>• Account setup and verification</Text>
        <Text style={styles.bulletPoint}>• Subscription and billing issues</Text>
        <Text style={styles.bulletPoint}>• Exchange API integration</Text>
        <Text style={styles.bulletPoint}>• Auto-trading configuration</Text>
        <Text style={styles.bulletPoint}>• Technical troubleshooting</Text>
        <Text style={styles.bulletPoint}>• General platform questions</Text>
      </View>

      <View style={{ height: 20 }} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  content: {
    padding: 12,
  },
  header: {
    backgroundColor: COLORS.teal,
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.gold,
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#fff',
  },
  quickContact: {
    backgroundColor: COLORS.cardBackground,
    borderRadius: 12,
    padding: 14,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 4,
  },
  sectionSubtitle: {
    fontSize: 13,
    color: '#999',
    marginBottom: 12,
  },
  contactButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1A2A35',
    padding: 12,
    borderRadius: 8,
    marginTop: 8,
  },
  contactIcon: {
    fontSize: 28,
    marginRight: 12,
  },
  contactInfo: {
    flex: 1,
  },
  contactLabel: {
    fontSize: 12,
    color: '#999',
    marginBottom: 2,
  },
  contactValue: {
    fontSize: 14,
    color: '#fff',
    fontWeight: '500',
  },
  formCard: {
    backgroundColor: COLORS.cardBackground,
    borderRadius: 12,
    padding: 14,
    marginBottom: 16,
  },
  inputGroup: {
    marginBottom: 14,
  },
  inputLabel: {
    fontSize: 14,
    color: '#fff',
    marginBottom: 6,
    fontWeight: '500',
  },
  input: {
    backgroundColor: '#1A2A35',
    borderRadius: 8,
    padding: 12,
    color: '#fff',
    fontSize: 14,
    borderWidth: 1,
    borderColor: '#2A3A45',
  },
  textArea: {
    height: 120,
    paddingTop: 12,
  },
  sendButton: {
    backgroundColor: COLORS.gold,
    padding: 14,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 8,
  },
  sendButtonDisabled: {
    opacity: 0.6,
  },
  sendButtonText: {
    color: '#0A4A5C',
    fontSize: 16,
    fontWeight: 'bold',
    marginRight: 8,
  },
  sendButtonIcon: {
    fontSize: 18,
  },
  infoCard: {
    backgroundColor: COLORS.cardBackground,
    borderRadius: 12,
    padding: 14,
    marginBottom: 12,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.gold,
    marginBottom: 8,
  },
  infoText: {
    fontSize: 13,
    color: '#ccc',
    marginBottom: 4,
  },
  bulletPoint: {
    fontSize: 13,
    color: '#ccc',
    marginBottom: 4,
    lineHeight: 20,
  },
});

export default SupportScreen;
