import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  RefreshControl,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { positionsAPI } from '../services/api';
import { COLORS } from '../constants/colors';

export default function PositionsScreen() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('active');
  const [positions, setPositions] = useState([]);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadPositions();
  }, []);

  const loadPositions = async () => {
    try {
      if (user?.user_id) {
        const response = await positionsAPI.getUserPositions(user.user_id);
        setPositions(response.data.positions || []);
      } else {
        setPositions([]);
      }
    } catch (error) {
      console.error('Error loading positions:', error);
      Alert.alert(
        'Error Loading Positions', 
        'Failed to load positions. Please check your connection and try again.'
      );
      setPositions([]);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadPositions();
    setRefreshing(false);
  };

  const getFilteredPositions = () => {
    return positions.filter((p) => {
      if (activeTab === 'active') return p.status === 'active';
      return p.status === 'closed';
    });
  };

  const getPnLColor = (pnl) => {
    return pnl >= 0 ? COLORS.tealBright : COLORS.goldDark;
  };

  const getDirectionColor = (direction) => {
    return direction === 'LONG' ? COLORS.tealBright : COLORS.goldDark;
  };

  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now - date;
    const hours = Math.floor(diff / 3600000);
    
    if (hours < 24) return `${hours}h ago`;
    return date.toLocaleDateString();
  };

  const renderPosition = ({ item }) => (
    <View style={styles.positionCard}>
      <View style={styles.positionHeader}>
        <View style={styles.symbolContainer}>
          <Text style={styles.symbol}>{item.symbol}</Text>
          <View style={[styles.directionBadge, { backgroundColor: getDirectionColor(item.direction) }]}>
            <Text style={styles.directionText}>{item.direction}</Text>
          </View>
        </View>
        <View>
          <Text style={[styles.pnl, { color: getPnLColor(item.pnl) }]}>
            {item.pnl >= 0 ? '+' : ''}${item.pnl.toFixed(2)}
          </Text>
          <Text style={[styles.pnlPercent, { color: getPnLColor(item.pnl) }]}>
            {item.pnl >= 0 ? '+' : ''}{item.pnl_percent.toFixed(2)}%
          </Text>
        </View>
      </View>

      <View style={styles.detailsRow}>
        <View style={styles.detailItem}>
          <Text style={styles.detailLabel}>Entry</Text>
          <Text style={styles.detailValue}>${item.entry_price.toLocaleString()}</Text>
        </View>
        <View style={styles.detailItem}>
          <Text style={styles.detailLabel}>Current</Text>
          <Text style={styles.detailValue}>${item.current_price.toLocaleString()}</Text>
        </View>
        <View style={styles.detailItem}>
          <Text style={styles.detailLabel}>Leverage</Text>
          <Text style={styles.detailValue}>x{item.leverage}</Text>
        </View>
      </View>

      {item.reached_targets && item.reached_targets.length > 0 && (
        <View style={styles.targetsRow}>
          <Text style={styles.targetsLabel}>Targets Hit:</Text>
          <View style={styles.targetsIndicators}>
            {[1, 2, 3, 4].map((num) => (
              <View
                key={num}
                style={[
                  styles.targetDot,
                  {
                    backgroundColor: item.reached_targets.includes(num)
                      ? COLORS.tealBright
                      : COLORS.border,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.targetDotText,
                    {
                      color: item.reached_targets.includes(num) ? COLORS.bgDark : '#666',
                    },
                  ]}
                >
                  {num}
                </Text>
              </View>
            ))}
          </View>
        </View>
      )}

      <View style={styles.footer}>
        <Text style={styles.timestamp}>
          Opened {formatTime(item.opened_at)}
        </Text>
        {item.status === 'closed' && item.closed_at && (
          <Text style={styles.closedBadge}>CLOSED</Text>
        )}
      </View>
    </View>
  );

  const renderEmpty = () => (
    <View style={styles.emptyContainer}>
      <Text style={styles.emptyIcon}>📊</Text>
      <Text style={styles.emptyTitle}>
        No {activeTab === 'active' ? 'Active' : 'Closed'} Positions
      </Text>
      <Text style={styles.emptyText}>
        {activeTab === 'active'
          ? 'Your active trades will appear here'
          : 'Your trading history will appear here'}
      </Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'active' && styles.activeTab]}
          onPress={() => setActiveTab('active')}
        >
          <Text style={[styles.tabText, activeTab === 'active' && styles.activeTabText]}>
            Active
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'closed' && styles.activeTab]}
          onPress={() => setActiveTab('closed')}
        >
          <Text style={[styles.tabText, activeTab === 'closed' && styles.activeTabText]}>
            Closed
          </Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={getFilteredPositions()}
        renderItem={renderPosition}
        keyExtractor={(item) => item.position_id}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.gold} />
        }
        ListEmptyComponent={renderEmpty}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bgDark,
  },
  tabContainer: {
    flexDirection: 'row',
    padding: 16,
    gap: 12,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: COLORS.bgCard,
    alignItems: 'center',
  },
  activeTab: {
    backgroundColor: COLORS.goldDark,
  },
  tabText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textSecondary,
  },
  activeTabText: {
    color: COLORS.textPrimary,
  },
  listContent: {
    padding: 16,
    paddingTop: 0,
  },
  positionCard: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  positionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  symbolContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  symbol: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginRight: 12,
  },
  directionBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  directionText: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.bgDark,
  },
  pnl: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  pnlPercent: {
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'right',
    marginTop: 2,
  },
  detailsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  detailItem: {
    flex: 1,
  },
  detailLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginBottom: 4,
  },
  detailValue: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textPrimary,
  },
  targetsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  targetsLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginRight: 12,
  },
  targetsIndicators: {
    flexDirection: 'row',
    gap: 8,
  },
  targetDot: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  targetDotText: {
    fontSize: 12,
    fontWeight: '700',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  timestamp: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  closedBadge: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.textSecondary,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 50,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    textAlign: 'center',
  },
});
