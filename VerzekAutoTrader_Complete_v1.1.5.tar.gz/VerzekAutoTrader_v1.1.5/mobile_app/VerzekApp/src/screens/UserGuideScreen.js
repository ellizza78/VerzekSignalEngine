import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { COLORS } from '../constants/colors';

const UserGuideScreen = ({ navigation }) => {
  const guideTopics = [
    {
      id: 1,
      title: 'Getting Started with VerzekAutoTrader',
      description: 'Learn the basics of setting up your account and connecting exchanges',
    },
    {
      id: 2,
      title: 'Exchange API Binding Guide',
      description: 'Step-by-step instructions for connecting Binance, Bybit, Phemex, and Kraken',
    },
    {
      id: 3,
      title: 'DCA Strategy Explained',
      description: 'Understanding Dollar Cost Averaging and how it works with VerzekAutoTrader',
    },
    {
      id: 4,
      title: 'Subscription Plans & Features',
      description: 'Compare FREE, PRO, and VIP plans to choose what\'s right for you',
    },
    {
      id: 5,
      title: 'Referral Rewards Program',
      description: 'Earn 10% monthly commissions by inviting friends',
    },
    {
      id: 6,
      title: 'Payment & Withdrawal Guide',
      description: 'How to pay with USDT (TRC20) and request payouts',
    },
    {
      id: 7,
      title: 'Trading Settings & Risk Management',
      description: 'Configure DCA settings, stop-loss, and take-profit levels',
    },
    {
      id: 8,
      title: 'Signal Quality Filter',
      description: 'Understanding the 60+ score threshold for auto-trading',
    },
    {
      id: 9,
      title: 'Demo vs Live Mode',
      description: 'Practice with virtual funds before trading with real capital',
    },
    {
      id: 10,
      title: 'IP Whitelisting for Exchanges',
      description: 'Security best practices for API key protection',
    },
    {
      id: 11,
      title: 'Troubleshooting Common Issues',
      description: 'Solutions for login errors, connection problems, and more',
    },
    {
      id: 12,
      title: 'Account Security & 2FA',
      description: 'Protect your account with two-factor authentication',
    },
  ];

  const handleTopicPress = (topic) => {
    navigation.navigate('GuideDetail', { topic });
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {guideTopics.map((topic) => (
        <TouchableOpacity
          key={topic.id}
          style={styles.topicCard}
          onPress={() => handleTopicPress(topic)}
        >
          <View style={styles.topicContent}>
            <Text style={styles.topicTitle}>{topic.title}</Text>
            {topic.description && (
              <Text style={styles.topicDescription}>{topic.description}</Text>
            )}
          </View>
          <Text style={styles.arrow}>›</Text>
        </TouchableOpacity>
      ))}

      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Need more help? Contact support via Telegram
        </Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bgDark,
  },
  content: {
    paddingBottom: 20,
  },
  topicCard: {
    backgroundColor: COLORS.bgCard,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    paddingVertical: 18,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  topicContent: {
    flex: 1,
    marginRight: 12,
  },
  topicTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: COLORS.textPrimary,
    lineHeight: 22,
  },
  topicDescription: {
    fontSize: 13,
    color: COLORS.textSecondary,
    marginTop: 4,
    lineHeight: 18,
  },
  arrow: {
    fontSize: 24,
    color: COLORS.textMuted,
    fontWeight: '300',
  },
  footer: {
    padding: 24,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    textAlign: 'center',
  },
});

export default UserGuideScreen;
