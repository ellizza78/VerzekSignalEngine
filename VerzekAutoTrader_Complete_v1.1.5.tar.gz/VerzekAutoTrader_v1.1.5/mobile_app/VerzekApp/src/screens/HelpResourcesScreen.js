import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Linking,
  Alert,
} from 'react-native';
import { COLORS } from '../constants/colors';

export default function HelpResourcesScreen({ navigation }) {
  const resources = [
    {
      id: 1,
      icon: '📖',
      title: 'Exchange Setup Guides',
      description: 'Step-by-step instructions for connecting exchanges',
      url: 'https://verzekinnovative.com/guides/exchange-setup.html',
      color: COLORS.teal,
    },
    {
      id: 2,
      icon: '🔗',
      title: 'Binance Connection Guide',
      description: 'How to create API keys and connect Binance',
      url: 'https://verzekinnovative.com/guides/exchange-setup.html#binance',
      color: COLORS.gold,
    },
    {
      id: 3,
      icon: '🎥',
      title: 'Video Tutorials',
      description: 'Watch step-by-step video guides (Coming Soon)',
      url: 'https://youtube.com/@verzektrader',
      color: '#FF0000',
      comingSoon: true,
    },
    {
      id: 4,
      icon: '🔐',
      title: 'Security Best Practices',
      description: 'Learn how to keep your API keys safe',
      url: 'https://verzekinnovative.com/guides/exchange-setup.html#security',
      color: COLORS.tealBright,
    },
    {
      id: 5,
      icon: '❓',
      title: 'FAQ',
      description: 'Frequently asked questions',
      action: () => navigation.navigate('FAQ'),
      color: COLORS.gold,
    },
    {
      id: 6,
      icon: '💬',
      title: 'Contact Support',
      description: 'Get help from our support team',
      url: 'mailto:support@verzekinnovative.com?subject=Help%20Request',
      color: COLORS.teal,
    },
    {
      id: 7,
      icon: '📱',
      title: 'User Guide',
      description: 'Learn how to use VerzekAutoTrader',
      action: () => navigation.navigate('UserGuide'),
      color: COLORS.tealBright,
    },
    {
      id: 8,
      icon: '🔧',
      title: 'Troubleshooting',
      description: 'Fix common connection issues',
      url: 'https://verzekinnovative.com/guides/exchange-setup.html#troubleshooting',
      color: COLORS.gold,
    },
  ];

  const handleResourcePress = async (resource) => {
    if (resource.comingSoon) {
      Alert.alert(
        'Coming Soon',
        'Video tutorials will be available soon! Check back later.',
        [{ text: 'OK' }]
      );
      return;
    }

    if (resource.action) {
      resource.action();
    } else if (resource.url) {
      try {
        const canOpen = await Linking.canOpenURL(resource.url);
        if (canOpen) {
          await Linking.openURL(resource.url);
        } else {
          Alert.alert('Error', 'Unable to open this link');
        }
      } catch (error) {
        Alert.alert('Error', 'Failed to open link');
      }
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerIcon}>📚</Text>
        <Text style={styles.headerTitle}>Help & Resources</Text>
        <Text style={styles.headerSubtitle}>
          Everything you need to get started and succeed
        </Text>
      </View>

      {/* Quick Links Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Quick Links</Text>
        {resources.map((resource) => (
          <TouchableOpacity
            key={resource.id}
            style={[
              styles.resourceCard,
              resource.comingSoon && styles.resourceCardDisabled,
            ]}
            onPress={() => handleResourcePress(resource)}
            activeOpacity={0.7}
          >
            <View style={styles.resourceIcon}>
              <Text style={styles.resourceIconText}>{resource.icon}</Text>
            </View>
            <View style={styles.resourceContent}>
              <View style={styles.resourceHeader}>
                <Text style={styles.resourceTitle}>{resource.title}</Text>
                {resource.comingSoon && (
                  <View style={styles.comingSoonBadge}>
                    <Text style={styles.comingSoonText}>Soon</Text>
                  </View>
                )}
              </View>
              <Text style={styles.resourceDescription}>
                {resource.description}
              </Text>
            </View>
            <Text style={[styles.resourceArrow, { color: resource.color }]}>
              →
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Support Info Section */}
      <View style={styles.infoSection}>
        <Text style={styles.infoTitle}>Need More Help?</Text>
        <Text style={styles.infoText}>
          Our support team is available 24/7 to assist you with any questions or
          issues.
        </Text>
        <TouchableOpacity
          style={styles.supportButton}
          onPress={() =>
            Linking.openURL(
              'mailto:support@verzekinnovative.com?subject=Support%20Request'
            )
          }
        >
          <Text style={styles.supportButtonIcon}>📧</Text>
          <Text style={styles.supportButtonText}>
            support@verzekinnovative.com
          </Text>
        </TouchableOpacity>
      </View>

      {/* Tips Section */}
      <View style={styles.tipsSection}>
        <Text style={styles.tipsTitle}>💡 Quick Tips</Text>
        <View style={styles.tipItem}>
          <Text style={styles.tipBullet}>•</Text>
          <Text style={styles.tipText}>
            Always enable IP whitelisting for extra security (45.76.90.149)
          </Text>
        </View>
        <View style={styles.tipItem}>
          <Text style={styles.tipBullet}>•</Text>
          <Text style={styles.tipText}>
            Never enable withdrawal permissions on your API keys
          </Text>
        </View>
        <View style={styles.tipItem}>
          <Text style={styles.tipBullet}>•</Text>
          <Text style={styles.tipText}>
            Start with small positions to test the system
          </Text>
        </View>
        <View style={styles.tipItem}>
          <Text style={styles.tipBullet}>•</Text>
          <Text style={styles.tipText}>
            Check the FAQ section for answers to common questions
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bgDark,
  },
  content: {
    paddingBottom: 30,
  },
  header: {
    padding: 24,
    alignItems: 'center',
    backgroundColor: COLORS.bgCard,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  headerIcon: {
    fontSize: 48,
    marginBottom: 12,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    textAlign: 'center',
  },
  section: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginBottom: 16,
  },
  resourceCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.bgCard,
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  resourceCardDisabled: {
    opacity: 0.6,
  },
  resourceIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: COLORS.bgDark,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  resourceIconText: {
    fontSize: 24,
  },
  resourceContent: {
    flex: 1,
  },
  resourceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  resourceTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginRight: 8,
  },
  comingSoonBadge: {
    backgroundColor: COLORS.gold + '30',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
  },
  comingSoonText: {
    fontSize: 10,
    fontWeight: '700',
    color: COLORS.gold,
  },
  resourceDescription: {
    fontSize: 13,
    color: COLORS.textSecondary,
    lineHeight: 18,
  },
  resourceArrow: {
    fontSize: 24,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  infoSection: {
    margin: 16,
    padding: 20,
    backgroundColor: COLORS.teal + '20',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.teal + '40',
  },
  infoTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.teal,
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    lineHeight: 20,
    marginBottom: 16,
  },
  supportButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.teal,
    padding: 14,
    borderRadius: 8,
    justifyContent: 'center',
  },
  supportButtonIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  supportButtonText: {
    fontSize: 15,
    fontWeight: '600',
    color: COLORS.bgDark,
  },
  tipsSection: {
    margin: 16,
    padding: 20,
    backgroundColor: COLORS.bgCard,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  tipsTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.gold,
    marginBottom: 12,
  },
  tipItem: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  tipBullet: {
    color: COLORS.gold,
    fontSize: 16,
    marginRight: 8,
    fontWeight: 'bold',
  },
  tipText: {
    flex: 1,
    fontSize: 14,
    color: COLORS.textSecondary,
    lineHeight: 20,
  },
});
