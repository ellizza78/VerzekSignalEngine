import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  RefreshControl,
  ActivityIndicator,
  Linking
} from 'react-native';
import { COLORS } from '../constants/colors';
import { useAuth } from '../context/AuthContext';

const ExchangeAccountsScreen = ({ navigation }) => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const exchanges = [
    { id: 'binance', name: 'Binance', icon: '📊', isConnected: false },
    { id: 'bybit', name: 'Bybit', icon: '🔷', isConnected: false },
    { id: 'phemex', name: 'Phemex', icon: '⚡', isConnected: false },
    { id: 'kraken', name: 'Kraken', icon: '🐙', isConnected: false },
  ];

  // Check which exchanges are connected
  const connectedExchanges = exchanges.map(exchange => ({
    ...exchange,
    isConnected: user?.exchange_accounts?.some(acc => acc.exchange === exchange.id) || false
  }));

  const onRefresh = () => {
    setRefreshing(true);
    // Refresh user data would happen here
    setTimeout(() => setRefreshing(false), 500);
  };

  const renderExchangeCard = (exchange) => (
    <TouchableOpacity
      key={exchange.id}
      style={styles.exchangeCard}
      onPress={() => navigation.navigate('ExchangeDetail', { exchangeId: exchange.id })}
    >
      <View style={styles.exchangeIcon}>
        <Text style={styles.exchangeIconText}>{exchange.icon}</Text>
      </View>
      <Text style={styles.exchangeName}>{exchange.name}</Text>
      <View style={styles.exchangeStatus}>
        {exchange.isConnected ? (
          <Text style={styles.connectedIcon}>🔗</Text>
        ) : (
          <Text style={styles.lockedIcon}>🔒</Text>
        )}
      </View>
    </TouchableOpacity>
  );

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.gold} />
      }
    >
      {/* Header Card */}
      <View style={styles.headerCard}>
        <View style={styles.headerContent}>
          <Text style={styles.headerTitle}>Exchange API Binding</Text>
          <Text style={styles.headerSubtitle}>
            Trade directly with your exchange wallet capital now.
          </Text>
        </View>
        <View style={styles.headerIcon}>
          <Text style={styles.headerIconText}>🔗</Text>
        </View>
      </View>

      {/* Exchange List */}
      <View style={styles.exchangeList}>
        {connectedExchanges.map(renderExchangeCard)}
      </View>

      {/* Footer Note */}
      <Text style={styles.footerText}>
        Connecting to more than one Exchange is also an option.
      </Text>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bgDark,
  },
  content: {
    padding: 12,
    paddingBottom: 12,
  },
  headerCard: {
    backgroundColor: COLORS.tealMid,
    borderRadius: 12,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  headerContent: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 14,
    color: COLORS.textPrimary,
    lineHeight: 20,
  },
  headerIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#10B981',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerIconText: {
    fontSize: 28,
  },
  exchangeList: {
    marginBottom: 20,
  },
  exchangeCard: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 16,
    padding: 18,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  exchangeIcon: {
    width: 56,
    height: 56,
    borderRadius: 12,
    backgroundColor: COLORS.bgMid,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  exchangeIconText: {
    fontSize: 28,
  },
  exchangeName: {
    flex: 1,
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.textPrimary,
  },
  exchangeStatus: {
    width: 40,
    alignItems: 'center',
  },
  connectedIcon: {
    fontSize: 24,
    color: COLORS.tealBright,
  },
  lockedIcon: {
    fontSize: 24,
    opacity: 0.5,
  },
  footerText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 8,
  },
});

export default ExchangeAccountsScreen;
