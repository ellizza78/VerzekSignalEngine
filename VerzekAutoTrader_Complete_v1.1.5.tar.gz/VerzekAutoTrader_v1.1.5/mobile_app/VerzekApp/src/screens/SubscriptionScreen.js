import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Image,
} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { useAuth } from '../context/AuthContext';
import { paymentAPI } from '../services/api';
import { COLORS } from '../constants/colors';

const SubscriptionScreen = ({ navigation }) => {
  const { user, refreshUser } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [txHash, setTxHash] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [loading, setLoading] = useState(false);

  const ADMIN_WALLET = 'TBjfqimYNsPecGxsk9kcX8GboPyZcWHNzb';

  const plans = [
    {
      id: 'trial',
      name: 'TRIAL',
      price: 0,
      duration: 4,
      features: [
        '✅ 4 Days Free Trial',
        '✅ Access to Trial Telegram Group',
        '✅ Basic Signals Preview',
        '❌ No Auto-Trading',
        '❌ Limited Signal Quality',
        '📞 Contact @VerzekSupport on Telegram',
      ],
      color: '#6B7280',
      free: true,
    },
    {
      id: 'vip',
      name: 'VIP',
      price: 50,
      duration: 30,
      features: [
        '✅ Premium Telegram Signals',
        '✅ Signal Quality Filter (60+ score)',
        '✅ Priority Signal Access',
        '✅ VIP-Only Telegram Group',
        '❌ Auto-Trading (Manual execution only)',
      ],
      color: '#9333EA',
    },
    {
      id: 'premium',
      name: 'PREMIUM',
      price: 120,
      duration: 30,
      features: [
        '✅ Everything in VIP',
        '✅ Full Auto-Trading System',
        '✅ Multi-Exchange Support',
        '✅ DCA Strategy Execution',
        '✅ Progressive Take-Profit',
        '✅ Auto-Stop Logic',
        '✅ Position Management',
      ],
      color: COLORS.goldDark,
      recommended: true,
    },
  ];

  const copyToClipboard = async (text, label) => {
    await Clipboard.setStringAsync(text);
    Alert.alert('Copied!', `${label} copied to clipboard`);
  };

  const handleSelectPlan = (plan) => {
    setSelectedPlan(plan);
  };

  const handleActivateTrial = async () => {
    try {
      setLoading(true);
      // Activate trial subscription
      const result = await paymentAPI.submitPayment(
        'trial',
        0,
        'TRIAL_ACTIVATION',
        referralCode
      );

      if (result.success) {
        Alert.alert(
          'Trial Activated!',
          'Your 4-day trial has been activated. Check your Telegram for the trial group link!',
          [
            {
              text: 'OK',
              onPress: () => navigation.goBack(),
            },
          ]
        );
      }
    } catch (error) {
      Alert.alert('Error', error.response?.data?.error || 'Failed to activate trial');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitPayment = async () => {
    if (!selectedPlan) {
      Alert.alert('Error', 'Please select a subscription plan');
      return;
    }

    // Handle trial activation separately
    if (selectedPlan.free) {
      handleActivateTrial();
      return;
    }

    if (!txHash || txHash.length < 10) {
      Alert.alert('Error', 'Please enter a valid transaction hash');
      return;
    }

    try {
      setLoading(true);
      const result = await paymentAPI.submitPayment(
        selectedPlan.id,
        selectedPlan.price,
        txHash,
        referralCode
      );

      if (result.success) {
        Alert.alert(
          'Payment Submitted',
          'Your payment has been submitted for verification. Admin will confirm within 24 hours.',
          [
            {
              text: 'OK',
              onPress: () => {
                setTxHash('');
                setReferralCode('');
                navigation.goBack();
              },
            },
          ]
        );
      }
    } catch (error) {
      Alert.alert('Error', error.response?.data?.error || 'Failed to submit payment');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>Choose Your Plan</Text>
      <Text style={styles.subtitle}>Unlock premium features with USDT payment</Text>

      {/* Plan Selection */}
      <View style={styles.plansContainer}>
        {plans.map((plan) => (
          <TouchableOpacity
            key={plan.id}
            style={[
              styles.planCard,
              selectedPlan?.id === plan.id && styles.planCardSelected,
              { borderColor: plan.color },
            ]}
            onPress={() => handleSelectPlan(plan)}
          >
            {plan.recommended && (
              <View style={[styles.recommendedBadge, { backgroundColor: plan.color }]}>
                <Text style={styles.recommendedText}>RECOMMENDED</Text>
              </View>
            )}

            <Text style={[styles.planName, { color: plan.color }]}>{plan.name}</Text>
            <View style={styles.priceContainer}>
              <Text style={styles.priceAmount}>${plan.price}</Text>
              <Text style={styles.pricePeriod}> USDT / {plan.duration} days</Text>
            </View>

            <View style={styles.featuresContainer}>
              {plan.features.map((feature, index) => (
                <Text key={index} style={styles.featureText}>
                  {feature}
                </Text>
              ))}
            </View>

            {selectedPlan?.id === plan.id && (
              <View style={[styles.selectedIndicator, { backgroundColor: plan.color }]}>
                <Text style={styles.selectedText}>✓ Selected</Text>
              </View>
            )}
          </TouchableOpacity>
        ))}
      </View>

      {/* Payment Instructions */}
      {selectedPlan && (
        <View style={styles.paymentSection}>
          <Text style={styles.sectionTitle}>Payment Instructions</Text>

          <View style={styles.instructionCard}>
            {selectedPlan.free ? (
              <>
                <Text style={styles.trialInfo}>
                  Click "Activate Trial" below to start your 4-day free trial. You'll receive a Telegram group link instantly!
                </Text>
              </>
            ) : (
              <>
                <Text style={styles.instructionStep}>Step 1: Send USDT (TRC20)</Text>
                <View style={styles.walletRow}>
                  <Text style={styles.walletLabel}>Admin Wallet:</Text>
                  <TouchableOpacity onPress={() => copyToClipboard(ADMIN_WALLET, 'Wallet address')}>
                    <Text style={styles.walletAddress} numberOfLines={1}>
                      {ADMIN_WALLET}
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => copyToClipboard(ADMIN_WALLET, 'Wallet address')}>
                    <Text style={styles.copyButton}>📋 Copy</Text>
                  </TouchableOpacity>
                </View>

                <View style={styles.amountRow}>
                  <Text style={styles.amountLabel}>Amount:</Text>
                  <Text style={styles.amountValue}>{selectedPlan.price} USDT</Text>
                </View>

                <Text style={styles.warning}>
                  ⚠️ Make sure to send EXACT amount on TRC20 network only!
                </Text>
              </>
            )}
          </View>

          <View style={styles.instructionCard}>
            <Text style={styles.instructionStep}>
              {selectedPlan.free ? 'Activate Your Trial' : 'Step 2: Submit Transaction Hash'}
            </Text>

            {!selectedPlan.free && (
              <TextInput
                style={styles.input}
                placeholder="Transaction Hash (TX Hash)"
                placeholderTextColor={COLORS.textMuted}
                value={txHash}
                onChangeText={setTxHash}
                autoCapitalize="none"
              />
            )}

            <TextInput
              style={styles.input}
              placeholder="Referral Code (Optional)"
              placeholderTextColor={COLORS.textMuted}
              value={referralCode}
              onChangeText={setReferralCode}
              autoCapitalize="none"
            />

            <TouchableOpacity
              style={[styles.submitButton, loading && styles.submitButtonDisabled]}
              onPress={handleSubmitPayment}
              disabled={loading}
            >
              <Text style={styles.submitButtonText}>
                {loading ? (selectedPlan.free ? 'Activating...' : 'Submitting...') : 
                  (selectedPlan.free ? 'Activate Trial' : 'Submit Payment')}
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.helpCard}>
            <Text style={styles.helpTitle}>Need Help?</Text>
            <Text style={styles.helpText}>
              Contact support via Telegram: @VerzekSupport{'\n'}
              Email: support@verzektrader.com
            </Text>
          </View>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bgDark,
  },
  content: {
    padding: 12,
    paddingBottom: 12,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginBottom: 24,
  },
  plansContainer: {
    marginBottom: 32,
  },
  planCard: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: COLORS.border,
  },
  planCardSelected: {
    borderWidth: 3,
  },
  recommendedBadge: {
    position: 'absolute',
    top: -10,
    right: 20,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  recommendedText: {
    fontSize: 11,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
  },
  planName: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginBottom: 16,
  },
  priceAmount: {
    fontSize: 36,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
  },
  pricePeriod: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  featuresContainer: {
    marginTop: 8,
  },
  featureText: {
    fontSize: 14,
    color: COLORS.textPrimary,
    marginBottom: 8,
    lineHeight: 20,
  },
  selectedIndicator: {
    marginTop: 16,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  selectedText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.bgDark,
  },
  paymentSection: {
    marginTop: 8,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 16,
  },
  instructionCard: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  instructionStep: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.tealBright,
    marginBottom: 12,
  },
  walletRow: {
    marginBottom: 12,
  },
  walletLabel: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 6,
  },
  walletAddress: {
    fontSize: 13,
    color: COLORS.textPrimary,
    backgroundColor: COLORS.bgDark,
    padding: 12,
    borderRadius: 8,
    fontFamily: 'monospace',
    marginBottom: 8,
  },
  copyButton: {
    fontSize: 14,
    color: COLORS.tealBright,
    fontWeight: '600',
  },
  amountRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  amountLabel: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  amountValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.goldDark,
  },
  warning: {
    fontSize: 13,
    color: '#EF4444',
    fontStyle: 'italic',
    marginTop: 8,
  },
  trialInfo: {
    fontSize: 14,
    color: COLORS.textPrimary,
    lineHeight: 22,
    textAlign: 'center',
  },
  input: {
    backgroundColor: COLORS.bgDark,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 8,
    padding: 12,
    fontSize: 14,
    color: COLORS.textPrimary,
    marginBottom: 12,
  },
  submitButton: {
    backgroundColor: COLORS.tealBright,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 8,
  },
  submitButtonDisabled: {
    opacity: 0.5,
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.bgDark,
  },
  helpCard: {
    backgroundColor: `${COLORS.tealBright}1A`,
    borderWidth: 1,
    borderColor: COLORS.tealBright,
    borderRadius: 12,
    padding: 16,
  },
  helpTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.tealBright,
    marginBottom: 8,
  },
  helpText: {
    fontSize: 14,
    color: COLORS.textPrimary,
    lineHeight: 20,
  },
});

export default SubscriptionScreen;
