import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  TextInput,
  ActivityIndicator,
} from 'react-native';
import Slider from '@react-native-community/slider';
import * as Clipboard from 'expo-clipboard';
import { COLORS } from '../constants/colors';
import { EXCHANGE_CONFIG } from '../constants/exchangeConfig';
import { systemAPI, userAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';

const ExchangeDetailScreen = ({ route, navigation }) => {
  const { exchangeId } = route.params;
  const { user, refreshUser } = useAuth();
  const [serverIP, setServerIP] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [connectedAccount, setConnectedAccount] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  
  const [apiKey, setApiKey] = useState('');
  const [apiSecret, setApiSecret] = useState('');
  const [leverage, setLeverage] = useState(10);
  const [savingLeverage, setSavingLeverage] = useState(false);
  const [balance, setBalance] = useState(null);
  const [loadingBalance, setLoadingBalance] = useState(false);
  
  const config = EXCHANGE_CONFIG[exchangeId];

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const { data } = await systemAPI.getServerIP();
      // Only use the primary IP address that Binance accepts
      setServerIP('45.76.90.149');
      
      // Check if user has this exchange connected
      const connected = user?.exchange_accounts?.find(
        acc => acc.exchange === exchangeId
      );
      setConnectedAccount(connected);

      // Load leverage settings if connected
      if (connected && user?.user_id) {
        try {
          const leverageData = await userAPI.getExchangeLeverage(user.user_id, exchangeId);
          setLeverage(leverageData.data.leverage || 10);
        } catch (error) {
          console.log('No leverage settings found, using default');
        }
        
        // Load exchange balance
        loadExchangeBalance();
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to load exchange information');
    } finally {
      setLoading(false);
    }
  };

  const loadExchangeBalance = async () => {
    if (!user?.user_id) return;
    
    try {
      setLoadingBalance(true);
      const response = await userAPI.getExchangeBalance(user.user_id, exchangeId);
      setBalance(response.data);
    } catch (error) {
      console.error('Failed to load balance:', error);
      setBalance(null);
    } finally {
      setLoadingBalance(false);
    }
  };

  const copyIPToClipboard = async () => {
    await Clipboard.setStringAsync(serverIP);
    Alert.alert('Copied!', `IP Address ${serverIP} copied to clipboard`);
  };

  const handleAddAccount = async () => {
    if (!apiKey.trim() || !apiSecret.trim()) {
      Alert.alert('Error', 'Please enter both API Key and Secret Key');
      return;
    }

    try {
      setSaving(true);
      await userAPI.addExchangeAccount(user.user_id, {
        exchange: exchangeId,
        api_key: apiKey.trim(),
        api_secret: apiSecret.trim(),
      });
      
      Alert.alert('Success', `${config.name} account connected successfully!`);
      setApiKey('');
      setApiSecret('');
      setShowAddForm(false);
      await refreshUser();
      await fetchData();
    } catch (error) {
      const errorData = error.response?.data;
      const errorTitle = errorData?.error || 'Error';
      const errorMessage = errorData?.message || 'Failed to connect exchange account';
      
      Alert.alert(errorTitle, errorMessage);
    } finally {
      setSaving(false);
    }
  };

  const handleReplaceAccount = () => {
    Alert.alert(
      'Replace API Keys',
      `Are you sure you want to replace your ${config.name} API keys?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Replace',
          style: 'destructive',
          onPress: () => {
            setShowAddForm(true);
          },
        },
      ]
    );
  };

  const handleUnbindAccount = () => {
    Alert.alert(
      'Unbind Exchange',
      `Are you sure you want to remove your ${config.name} account? This will stop all active strategies.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Unbind',
          style: 'destructive',
          onPress: async () => {
            try {
              setSaving(true);
              await userAPI.removeExchangeAccount(user.user_id, connectedAccount.id);
              Alert.alert('Success', `${config.name} account removed`);
              await refreshUser();
              navigation.goBack();
            } catch (error) {
              Alert.alert('Error', 'Failed to remove exchange account');
            } finally {
              setSaving(false);
            }
          },
        },
      ]
    );
  };

  const handleLeverageChange = async (newLeverage) => {
    setLeverage(newLeverage);
    
    setSavingLeverage(true);
    try {
      await userAPI.updateExchangeLeverage(user.user_id, exchangeId, Math.round(newLeverage));
    } catch (error) {
      console.error('Failed to save leverage:', error);
    } finally {
      setTimeout(() => setSavingLeverage(false), 500);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.gold} />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.exchangeLogo}>{config.logo}</Text>
        <Text style={styles.exchangeName}>{config.name}</Text>
      </View>

      {/* Tabs */}
      <View style={styles.tabs}>
        <View style={[styles.tab, styles.tabActive]}>
          <Text style={[styles.tabText, styles.tabTextActive]}>Precautions</Text>
        </View>
        <View style={styles.tab}>
          <Text style={styles.tabText}>Instructions</Text>
        </View>
      </View>

      {/* Precautions Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Precautions</Text>
        {config.precautions.map((precaution, index) => (
          <Text key={index} style={styles.precautionText}>
            {index + 1}.{precaution}
          </Text>
        ))}
      </View>

      {/* IP Binding Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{config.ipBinding.title}</Text>
        <Text style={styles.description}>{config.ipBinding.description}</Text>
        
        <View style={styles.ipBox}>
          <Text style={styles.ipAddresses}>{serverIP}</Text>
          <TouchableOpacity style={styles.copyButton} onPress={copyIPToClipboard}>
            <Text style={styles.copyButtonText}>Copy</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Leverage Settings (Only shown when connected) */}
      {connectedAccount && !showAddForm && (
        <View style={styles.section}>
          <View style={styles.leverageHeader}>
            <Text style={styles.sectionTitle}>Leverage Setting</Text>
            {savingLeverage && (
              <Text style={styles.savingText}>Saving...</Text>
            )}
          </View>
          <Text style={styles.description}>
            Set the leverage for trades on this exchange. This will be used when opening positions.
          </Text>
          
          <View style={styles.leverageContainer}>
            <Text style={styles.leverageValue}>{Math.round(leverage)}x</Text>
            <Slider
              style={styles.leverageSlider}
              minimumValue={1}
              maximumValue={25}
              step={1}
              value={leverage}
              onValueChange={setLeverage}
              onSlidingComplete={handleLeverageChange}
              minimumTrackTintColor={COLORS.tealBright}
              maximumTrackTintColor={COLORS.border}
              thumbTintColor={COLORS.gold}
            />
            <View style={styles.leverageLabels}>
              <Text style={styles.leverageLabel}>1x</Text>
              <Text style={styles.leverageLabel}>5x</Text>
              <Text style={styles.leverageLabel}>10x</Text>
              <Text style={styles.leverageLabel}>15x</Text>
              <Text style={styles.leverageLabel}>20x</Text>
              <Text style={styles.leverageLabel}>25x</Text>
            </View>
          </View>
          
          <View style={styles.warningBox}>
            <Text style={styles.warningText}>
              ⚠️ Higher leverage = Higher risk. Use with caution!
            </Text>
          </View>
        </View>
      )}

      {/* Exchange Balance - Only shown when connected */}
      {connectedAccount && !showAddForm && (
        <View style={styles.section}>
          <View style={styles.balanceHeader}>
            <Text style={styles.sectionTitle}>💰 Exchange Balance</Text>
            <TouchableOpacity onPress={loadExchangeBalance} disabled={loadingBalance}>
              <Text style={styles.refreshButton}>{loadingBalance ? '🔄' : '🔃'}</Text>
            </TouchableOpacity>
          </View>
          
          {loadingBalance ? (
            <View style={styles.balanceLoading}>
              <ActivityIndicator size="small" color={COLORS.gold} />
              <Text style={styles.loadingText}>Loading balance...</Text>
            </View>
          ) : balance ? (
            <View style={styles.balanceCard}>
              <View style={styles.balanceRow}>
                <Text style={styles.balanceLabel}>Available USDT:</Text>
                <Text style={styles.balanceValue}>
                  ${balance.available_balance ? Number(balance.available_balance).toFixed(2) : '0.00'}
                </Text>
              </View>
              <View style={styles.balanceRow}>
                <Text style={styles.balanceLabel}>Total USDT:</Text>
                <Text style={styles.balanceValueTotal}>
                  ${balance.total_balance ? Number(balance.total_balance).toFixed(2) : '0.00'}
                </Text>
              </View>
              {balance.locked_balance && Number(balance.locked_balance) > 0 && (
                <View style={styles.balanceRow}>
                  <Text style={styles.balanceLabelSmall}>Locked in Trades:</Text>
                  <Text style={styles.balanceValueSmall}>
                    ${Number(balance.locked_balance).toFixed(2)}
                  </Text>
                </View>
              )}
            </View>
          ) : (
            <View style={styles.balanceError}>
              <Text style={styles.balanceErrorText}>
                ⚠️ Unable to fetch balance. Tap refresh to try again.
              </Text>
            </View>
          )}
        </View>
      )}

      {/* Connected Account or Add Form */}
      {connectedAccount && !showAddForm ? (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>API Key</Text>
          <View style={styles.keyDisplay}>
            <Text style={styles.keyText}>{connectedAccount.api_key}</Text>
          </View>
          
          <Text style={styles.sectionTitle}>Secret Key</Text>
          <View style={styles.keyDisplay}>
            <Text style={styles.keyText}>******</Text>
          </View>

          <TouchableOpacity style={styles.replaceButton} onPress={handleReplaceAccount}>
            <Text style={styles.replaceButtonText}>Replace</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.unbindButton} onPress={handleUnbindAccount}>
            <Text style={styles.unbindButtonText}>Unbind</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>API Key</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your API key"
            placeholderTextColor={COLORS.textMuted}
            value={apiKey}
            onChangeText={setApiKey}
            autoCapitalize="none"
            autoCorrect={false}
          />

          <Text style={styles.sectionTitle}>Secret Key</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your secret key"
            placeholderTextColor={COLORS.textMuted}
            value={apiSecret}
            onChangeText={setApiSecret}
            secureTextEntry
            autoCapitalize="none"
            autoCorrect={false}
          />

          <TouchableOpacity
            style={[styles.addButton, saving && styles.addButtonDisabled]}
            onPress={handleAddAccount}
            disabled={saving}
          >
            <Text style={styles.addButtonText}>
              {saving ? 'Connecting...' : connectedAccount ? 'Update Keys' : 'Connect Exchange'}
            </Text>
          </TouchableOpacity>

          {connectedAccount && (
            <TouchableOpacity
              style={styles.cancelButton}
              onPress={() => setShowAddForm(false)}
            >
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bgDark,
  },
  content: {
    paddingBottom: 20,
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: COLORS.bgDark,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    alignItems: 'center',
    paddingVertical: 24,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  exchangeLogo: {
    fontSize: 48,
    marginBottom: 8,
  },
  exchangeName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
  },
  tabs: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  tab: {
    flex: 1,
    paddingVertical: 16,
    alignItems: 'center',
  },
  tabActive: {
    borderBottomWidth: 2,
    borderBottomColor: COLORS.tealBright,
  },
  tabText: {
    fontSize: 16,
    color: COLORS.textSecondary,
  },
  tabTextActive: {
    color: COLORS.tealBright,
    fontWeight: '600',
  },
  section: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 12,
    marginTop: 8,
  },
  precautionText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    lineHeight: 22,
    marginBottom: 10,
  },
  description: {
    fontSize: 14,
    color: COLORS.textSecondary,
    lineHeight: 20,
    marginBottom: 16,
  },
  ipBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.bgCard,
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  ipAddresses: {
    flex: 1,
    fontSize: 14,
    color: COLORS.tealBright,
    fontWeight: '600',
  },
  copyButton: {
    backgroundColor: COLORS.tealBright,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  copyButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.bgDark,
  },
  keyDisplay: {
    backgroundColor: COLORS.bgCard,
    padding: 14,
    borderRadius: 8,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  keyText: {
    fontSize: 14,
    color: COLORS.textPrimary,
    fontFamily: 'monospace',
  },
  input: {
    backgroundColor: COLORS.bgCard,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 8,
    padding: 14,
    fontSize: 14,
    color: COLORS.textPrimary,
    marginBottom: 16,
  },
  addButton: {
    backgroundColor: COLORS.tealBright,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 8,
  },
  addButtonDisabled: {
    opacity: 0.5,
  },
  addButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.bgDark,
  },
  replaceButton: {
    backgroundColor: COLORS.tealBright,
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 8,
  },
  replaceButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.bgDark,
  },
  unbindButton: {
    backgroundColor: 'transparent',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 12,
    borderWidth: 1,
    borderColor: '#EF4444',
  },
  unbindButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#EF4444',
  },
  cancelButton: {
    backgroundColor: 'transparent',
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 12,
    borderWidth: 1,
    borderColor: COLORS.textMuted,
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textMuted,
  },
  leverageHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  savingText: {
    fontSize: 12,
    color: COLORS.tealBright,
    fontStyle: 'italic',
  },
  leverageContainer: {
    backgroundColor: COLORS.bgCard,
    padding: 20,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginBottom: 16,
  },
  leverageValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.gold,
    textAlign: 'center',
    marginBottom: 16,
  },
  balanceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  refreshButton: {
    fontSize: 24,
    color: COLORS.tealBright,
  },
  balanceLoading: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: COLORS.bgCard,
    borderRadius: 12,
  },
  loadingText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginLeft: 12,
  },
  balanceCard: {
    backgroundColor: `${COLORS.gold}15`,
    borderRadius: 12,
    padding: 16,
    borderWidth: 2,
    borderColor: COLORS.gold,
  },
  balanceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  balanceLabel: {
    fontSize: 15,
    color: COLORS.textSecondary,
    fontWeight: '500',
  },
  balanceValue: {
    fontSize: 18,
    color: COLORS.tealBright,
    fontWeight: '700',
  },
  balanceValueTotal: {
    fontSize: 24,
    color: COLORS.gold,
    fontWeight: '700',
  },
  balanceLabelSmall: {
    fontSize: 13,
    color: COLORS.textMuted,
  },
  balanceValueSmall: {
    fontSize: 14,
    color: COLORS.textMuted,
    fontWeight: '600',
  },
  balanceError: {
    backgroundColor: `${COLORS.goldDark}15`,
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.goldDark,
  },
  balanceErrorText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    textAlign: 'center',
  },
  leverageSlider: {
    width: '100%',
    height: 40,
  },
  leverageLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  leverageLabel: {
    fontSize: 12,
    color: COLORS.textMuted,
  },
  warningBox: {
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.3)',
  },
  warningText: {
    fontSize: 13,
    color: '#EF4444',
    textAlign: 'center',
  },
});

export default ExchangeDetailScreen;
