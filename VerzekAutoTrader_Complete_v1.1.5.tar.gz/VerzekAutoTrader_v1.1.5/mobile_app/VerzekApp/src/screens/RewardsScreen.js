import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  RefreshControl,
  ActivityIndicator,
  TextInput,
} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { COLORS } from '../constants/colors';
import { userAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';

const RewardsScreen = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState('all'); // all, activation, direct
  const [rewardsData, setRewardsData] = useState(null);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawAddress, setWithdrawAddress] = useState('');
  const [withdrawing, setWithdrawing] = useState(false);

  useEffect(() => {
    fetchRewards();
  }, []);

  const fetchRewards = async () => {
    try {
      setLoading(true);
      const statsResponse = await userAPI.getReferralRewards();
      const balanceResponse = await userAPI.getWalletBalance();
      const codeResponse = await userAPI.getReferralCode();
      
      setRewardsData({
        today_income: statsResponse.data.today_earnings || 0,
        total_income: statsResponse.data.total_earnings || 0,
        withdrawable_balance: balanceResponse.data.balance || 0,
        referral_code: codeResponse.data.referral_code || user?.referral_code || 'N/A',
      });
    } catch (error) {
      console.error('Rewards fetch error:', error);
      Alert.alert('Error', 'Failed to load rewards data');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    fetchRewards();
  };

  const handleWithdraw = async () => {
    if (!withdrawAmount || parseFloat(withdrawAmount) <= 0) {
      Alert.alert('Error', 'Please enter a valid amount');
      return;
    }

    if (!withdrawAddress || withdrawAddress.length < 30) {
      Alert.alert('Error', 'Please enter a valid USDT (TRC20) address');
      return;
    }

    const amount = parseFloat(withdrawAmount);
    if (amount > (rewardsData?.withdrawable_balance || 0)) {
      Alert.alert('Error', 'Insufficient balance');
      return;
    }

    if (amount < 10) {
      Alert.alert('Error', 'Minimum withdrawal amount is 10 USDT');
      return;
    }

    Alert.alert(
      'Confirm Withdrawal',
      `Withdraw ${amount} USDT to:\n${withdrawAddress.substring(0, 10)}...${withdrawAddress.substring(withdrawAddress.length - 10)}`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Confirm',
          onPress: async () => {
            try {
              setWithdrawing(true);
              await userAPI.requestPayout(user.user_id, {
                wallet_address: withdrawAddress,
              });
              Alert.alert(
                'Success',
                'Withdrawal request submitted! Admin will process it within 24 hours.'
              );
              setWithdrawAmount('');
              setWithdrawAddress('');
              setShowWithdrawModal(false);
              fetchRewards();
            } catch (error) {
              Alert.alert('Error', error.response?.data?.error || 'Failed to request withdrawal');
            } finally {
              setWithdrawing(false);
            }
          },
        },
      ]
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.gold} />
        <Text style={styles.loadingText}>Loading rewards...</Text>
      </View>
    );
  }

  const todayIncome = rewardsData?.today_income || 0;
  const totalIncome = rewardsData?.total_income || 0;
  const withdrawableBalance = rewardsData?.withdrawable_balance || 0;
  const referralCode = rewardsData?.referral_code || user?.referral_code || 'N/A';

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.gold} />
      }
    >
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Referral Rewards</Text>
        <Text style={styles.subtitle}>Earn 10% monthly recurring commissions</Text>
      </View>

      {/* Tabs */}
      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'all' && styles.tabActive]}
          onPress={() => setActiveTab('all')}
        >
          <Text style={[styles.tabText, activeTab === 'all' && styles.tabTextActive]}>All</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'activation' && styles.tabActive]}
          onPress={() => setActiveTab('activation')}
        >
          <Text style={[styles.tabText, activeTab === 'activation' && styles.tabTextActive]}>
            Activation Income
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'direct' && styles.tabActive]}
          onPress={() => setActiveTab('direct')}
        >
          <Text style={[styles.tabText, activeTab === 'direct' && styles.tabTextActive]}>
            Direct
          </Text>
        </TouchableOpacity>
      </View>

      {/* Income Summary Card */}
      <View style={styles.incomeCard}>
        <View style={styles.incomeLeft}>
          <View style={styles.incomeItem}>
            <Text style={styles.incomeLabel}>Today's Income (USDT)</Text>
            <View style={styles.incomeValueRow}>
              <Text style={styles.incomeValue}>{todayIncome.toFixed(2)}</Text>
              <Text style={styles.incomeEye}>👁</Text>
            </View>
            <Text style={styles.incomeUSD}>≈ ${(todayIncome * 1.0).toFixed(2)}</Text>
          </View>

          <View style={styles.incomeItem}>
            <Text style={styles.incomeLabel}>Total Income (USDT)</Text>
            <Text style={styles.incomeValue}>{totalIncome.toFixed(2)}</Text>
            <Text style={styles.incomeUSD}>≈ ${(totalIncome * 1.0).toFixed(2)}</Text>
          </View>
        </View>
        
        <View style={styles.coinIcon}>
          <Text style={styles.coinEmoji}>💰</Text>
        </View>
      </View>

      {/* Withdrawable Balance */}
      <View style={styles.balanceCard}>
        <Text style={styles.balanceLabel}>Withdrawable Balance</Text>
        <Text style={styles.balanceValue}>{withdrawableBalance.toFixed(2)} USDT</Text>
        <Text style={styles.balanceUSD}>≈ ${(withdrawableBalance * 1.0).toFixed(2)}</Text>
        
        <TouchableOpacity
          style={[styles.withdrawButton, withdrawableBalance < 10 && styles.withdrawButtonDisabled]}
          onPress={() => setShowWithdrawModal(true)}
          disabled={withdrawableBalance < 10}
        >
          <Text style={styles.withdrawButtonText}>
            {withdrawableBalance < 10 ? 'Min. 10 USDT Required' : 'Withdraw'}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Withdrawal Form */}
      {showWithdrawModal && (
        <View style={styles.withdrawModal}>
          <Text style={styles.modalTitle}>Withdraw USDT (TRC20)</Text>
          
          <Text style={styles.inputLabel}>Amount (USDT)</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter amount (min. 10 USDT)"
            placeholderTextColor={COLORS.textMuted}
            keyboardType="numeric"
            value={withdrawAmount}
            onChangeText={setWithdrawAmount}
          />

          <Text style={styles.inputLabel}>TRC20 Wallet Address</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your USDT TRC20 address"
            placeholderTextColor={COLORS.textMuted}
            value={withdrawAddress}
            onChangeText={setWithdrawAddress}
            autoCapitalize="none"
            autoCorrect={false}
          />

          <View style={styles.modalButtons}>
            <TouchableOpacity
              style={styles.modalCancelButton}
              onPress={() => setShowWithdrawModal(false)}
            >
              <Text style={styles.modalCancelText}>Cancel</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.modalConfirmButton, withdrawing && styles.modalConfirmButtonDisabled]}
              onPress={handleWithdraw}
              disabled={withdrawing}
            >
              <Text style={styles.modalConfirmText}>
                {withdrawing ? 'Processing...' : 'Confirm'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* Info Box */}
      <View style={styles.infoBox}>
        <Text style={styles.infoText}>
          💡 <Text style={styles.infoBold}>Note:</Text> Data within the past 24 hours may still be subject to rollover update.
        </Text>
      </View>

      {/* Referral Link Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Your Referral Code</Text>
        <View style={styles.referralCard}>
          <Text style={styles.referralCode}>
            {referralCode}
          </Text>
          <TouchableOpacity
            style={styles.copyButton}
            onPress={async () => {
              if (referralCode && referralCode !== 'N/A') {
                await Clipboard.setStringAsync(referralCode);
                Alert.alert('Copied!', 'Referral code copied to clipboard');
              }
            }}
          >
            <Text style={styles.copyButtonText}>Copy</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.referralInfo}>
          Share this code with friends. You'll earn 10% of their monthly subscription payments!
        </Text>
      </View>

      {/* Earnings History Placeholder */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Recent Earnings</Text>
        <View style={styles.emptyState}>
          <Text style={styles.emptyIcon}>📦</Text>
          <Text style={styles.emptyText}>No Data</Text>
          <Text style={styles.emptySubtext}>
            Your referral earnings will appear here
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bgDark,
  },
  content: {
    paddingBottom: 20,
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: COLORS.bgDark,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: COLORS.textSecondary,
  },
  header: {
    padding: 20,
    paddingTop: 12,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  tabs: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    paddingHorizontal: 8,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  tabActive: {
    borderBottomWidth: 2,
    borderBottomColor: COLORS.tealBright,
  },
  tabText: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  tabTextActive: {
    color: COLORS.tealBright,
    fontWeight: '600',
  },
  incomeCard: {
    backgroundColor: COLORS.tealMid,
    margin: 16,
    padding: 20,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  incomeLeft: {
    flex: 1,
  },
  incomeItem: {
    marginBottom: 16,
  },
  incomeLabel: {
    fontSize: 12,
    color: COLORS.textPrimary,
    marginBottom: 4,
  },
  incomeValueRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  incomeValue: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginRight: 8,
  },
  incomeEye: {
    fontSize: 16,
  },
  incomeUSD: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  coinIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: COLORS.goldDark,
    justifyContent: 'center',
    alignItems: 'center',
  },
  coinEmoji: {
    fontSize: 32,
  },
  balanceCard: {
    backgroundColor: COLORS.bgCard,
    marginHorizontal: 16,
    marginBottom: 16,
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    alignItems: 'center',
  },
  balanceLabel: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 8,
  },
  balanceValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.goldDark,
    marginBottom: 4,
  },
  balanceUSD: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 16,
  },
  withdrawButton: {
    backgroundColor: COLORS.gold,
    paddingHorizontal: 40,
    paddingVertical: 12,
    borderRadius: 12,
  },
  withdrawButtonDisabled: {
    backgroundColor: COLORS.textMuted,
  },
  withdrawButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.bgDark,
  },
  withdrawModal: {
    backgroundColor: COLORS.bgCard,
    marginHorizontal: 16,
    marginBottom: 16,
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: COLORS.tealBright,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 8,
    marginTop: 8,
  },
  input: {
    backgroundColor: COLORS.bgDark,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 8,
    padding: 14,
    fontSize: 14,
    color: COLORS.textPrimary,
    marginBottom: 12,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
  },
  modalCancelButton: {
    flex: 1,
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: COLORS.textMuted,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
  },
  modalCancelText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textMuted,
  },
  modalConfirmButton: {
    flex: 1,
    backgroundColor: COLORS.gold,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
  },
  modalConfirmButtonDisabled: {
    opacity: 0.5,
  },
  modalConfirmText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.bgDark,
  },
  infoBox: {
    backgroundColor: `${COLORS.tealBright}1A`,
    marginHorizontal: 16,
    marginBottom: 16,
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.tealBright,
  },
  infoText: {
    fontSize: 13,
    color: COLORS.textPrimary,
    lineHeight: 19,
  },
  infoBold: {
    fontWeight: 'bold',
    color: COLORS.tealBright,
  },
  section: {
    paddingHorizontal: 16,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 12,
  },
  referralCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.bgCard,
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginBottom: 12,
  },
  referralCode: {
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.tealBright,
    fontFamily: 'monospace',
  },
  copyButton: {
    backgroundColor: COLORS.tealBright,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  copyButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.bgDark,
  },
  referralInfo: {
    fontSize: 13,
    color: COLORS.textSecondary,
    lineHeight: 19,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.textSecondary,
    marginBottom: 4,
  },
  emptySubtext: {
    fontSize: 14,
    color: COLORS.textMuted,
  },
});

export default RewardsScreen;
