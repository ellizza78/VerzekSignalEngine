import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { COLORS } from '../constants/colors';
import { useAuth } from '../context/AuthContext';
import { authAPI } from '../services/api';

export default function EmailVerificationScreen({ navigation }) {
  const { user, checkVerificationStatus } = useAuth();
  const [loading, setLoading] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);

  useEffect(() => {
    let timer;
    if (resendCooldown > 0) {
      timer = setTimeout(() => setResendCooldown(resendCooldown - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [resendCooldown]);

  const handleResendVerification = async () => {
    if (resendCooldown > 0) return;

    setLoading(true);
    try {
      const response = await authAPI.resendVerification();
      
      Alert.alert(
        '✅ Email Sent',
        response.data.message || 'Verification email has been resent. Please check your inbox.',
        [{ text: 'OK' }]
      );
      
      setResendCooldown(60);
    } catch (error) {
      Alert.alert(
        'Error',
        error.response?.data?.error || 'Failed to resend verification email'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleCheckVerification = async () => {
    setLoading(true);
    try {
      const isVerified = await checkVerificationStatus();
      
      if (isVerified) {
        Alert.alert(
          '🎉 Email Verified!',
          'Your email has been verified successfully. You can now access all features.',
          [
            {
              text: 'Continue',
              onPress: () => navigation.replace('Dashboard')
            }
          ]
        );
      } else {
        Alert.alert(
          'Not Verified Yet',
          'Your email is not verified yet. Please check your inbox and click the verification link.',
          [{ text: 'OK' }]
        );
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to check verification status');
    } finally {
      setLoading(false);
    }
  };

  const handleSkip = () => {
    navigation.replace('Dashboard');
  };

  return (
    <LinearGradient
      colors={[COLORS.primaryDark, COLORS.primary]}
      style={styles.container}
    >
      <View style={styles.content}>
        <View style={styles.iconContainer}>
          <Ionicons name="mail" size={80} color={COLORS.accent} />
        </View>

        <Text style={styles.title}>Verify Your Email</Text>
        
        <Text style={styles.subtitle}>
          We sent a verification link to:
        </Text>
        
        <Text style={styles.email}>{user?.email}</Text>

        <View style={styles.instructions}>
          <View style={styles.instructionRow}>
            <Ionicons name="checkmark-circle" size={24} color={COLORS.accent} />
            <Text style={styles.instructionText}>
              Check your email inbox
            </Text>
          </View>
          
          <View style={styles.instructionRow}>
            <Ionicons name="checkmark-circle" size={24} color={COLORS.accent} />
            <Text style={styles.instructionText}>
              Click the verification link
            </Text>
          </View>
          
          <View style={styles.instructionRow}>
            <Ionicons name="checkmark-circle" size={24} color={COLORS.accent} />
            <Text style={styles.instructionText}>
              Come back here and tap "I've Verified"
            </Text>
          </View>
        </View>

        <TouchableOpacity
          style={styles.checkButton}
          onPress={handleCheckVerification}
          disabled={loading}
        >
          <LinearGradient
            colors={[COLORS.accent, COLORS.accentDark]}
            style={styles.buttonGradient}
          >
            {loading ? (
              <ActivityIndicator color="#FFF" />
            ) : (
              <>
                <Ionicons name="checkmark-done" size={24} color="#FFF" />
                <Text style={styles.buttonText}>I've Verified</Text>
              </>
            )}
          </LinearGradient>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.resendButton}
          onPress={handleResendVerification}
          disabled={loading || resendCooldown > 0}
        >
          <Text style={styles.resendButtonText}>
            {resendCooldown > 0
              ? `Resend in ${resendCooldown}s`
              : 'Resend Verification Email'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.skipButton}
          onPress={handleSkip}
        >
          <Text style={styles.skipButtonText}>
            Skip for now (Limited access)
          </Text>
        </TouchableOpacity>

        <View style={styles.warningBox}>
          <Ionicons name="warning" size={20} color={COLORS.accent} />
          <Text style={styles.warningText}>
            You cannot connect exchange accounts or trade until your email is verified.
          </Text>
        </View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconContainer: {
    marginBottom: 30,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFF',
    marginBottom: 10,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.8)',
    marginBottom: 10,
    textAlign: 'center',
  },
  email: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.accent,
    marginBottom: 30,
    textAlign: 'center',
  },
  instructions: {
    width: '100%',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 10,
    padding: 20,
    marginBottom: 30,
  },
  instructionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  instructionText: {
    fontSize: 16,
    color: '#FFF',
    marginLeft: 15,
    flex: 1,
  },
  checkButton: {
    width: '100%',
    marginBottom: 15,
    borderRadius: 10,
    overflow: 'hidden',
  },
  buttonGradient: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 15,
    gap: 10,
  },
  buttonText: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  resendButton: {
    marginBottom: 15,
  },
  resendButtonText: {
    color: COLORS.accent,
    fontSize: 16,
    textDecorationLine: 'underline',
  },
  skipButton: {
    marginBottom: 20,
  },
  skipButtonText: {
    color: 'rgba(255, 255, 255, 0.6)',
    fontSize: 14,
  },
  warningBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(249, 199, 79, 0.2)',
    borderLeftWidth: 4,
    borderLeftColor: COLORS.accent,
    padding: 15,
    borderRadius: 5,
    gap: 10,
  },
  warningText: {
    color: '#FFF',
    fontSize: 14,
    flex: 1,
  },
});
