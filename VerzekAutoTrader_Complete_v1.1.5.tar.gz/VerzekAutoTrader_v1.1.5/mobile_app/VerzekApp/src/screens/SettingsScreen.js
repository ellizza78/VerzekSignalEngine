import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  TextInput,
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { userAPI } from '../services/api';
import { COLORS } from '../constants/colors';

export default function SettingsScreen({ navigation }) {
  const { user, logout, refreshUser } = useAuth();
  const [loading, setLoading] = useState(false);
  
  // General Settings
  const [mode, setMode] = useState('demo');
  
  // Auto-Trading Control
  const [autoTradeEnabled, setAutoTradeEnabled] = useState(false);
  const [tradingPaused, setTradingPaused] = useState(false);
  
  // Capital & Risk Settings
  const [positionSize, setPositionSize] = useState('5.0');
  const [maxConcurrentTrades, setMaxConcurrentTrades] = useState('3');
  const [maxInvestment, setMaxInvestment] = useState('100.0');
  const [leverage, setLeverage] = useState('10');
  
  // Strategy Settings
  const [autoFollow, setAutoFollow] = useState(true);
  const [autoStopOnSignals, setAutoStopOnSignals] = useState(true);
  const [targetBasedTP, setTargetBasedTP] = useState(true);
  
  // Notification Settings
  const [notifyOnEntry, setNotifyOnEntry] = useState(true);
  const [notifyOnTP, setNotifyOnTP] = useState(true);
  const [notifyOnSL, setNotifyOnSL] = useState(true);
  const [notifyOnDCA, setNotifyOnDCA] = useState(true);

  const updateNotificationSettings = async (setting, value) => {
    try {
      setLoading(true);
      await userAPI.updatePreferences(user.user_id, { [setting]: value });
      await refreshUser();
    } catch (error) {
      Alert.alert('Error', 'Failed to update notification settings');
    } finally {
      setLoading(false);
    }
  };

  const handlePauseTrading = async () => {
    Alert.alert(
      'Pause Auto-Trading',
      'This will stop all automated trading. You can manually withdraw profits from your exchanges safely.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Pause Trading',
          style: 'destructive',
          onPress: async () => {
            try {
              setLoading(true);
              await userAPI.updatePreferences(user.user_id, { auto_trade_enabled: false });
              setAutoTradeEnabled(false);
              setTradingPaused(true);
              await refreshUser();
              Alert.alert('Success', 'Auto-trading paused. You can now safely withdraw profits.');
            } catch (error) {
              Alert.alert('Error', 'Failed to pause trading');
            } finally {
              setLoading(false);
            }
          },
        },
      ]
    );
  };

  const handleResumeTrading = async () => {
    try {
      setLoading(true);
      await userAPI.updatePreferences(user.user_id, { auto_trade_enabled: true });
      setAutoTradeEnabled(true);
      setTradingPaused(false);
      await refreshUser();
      Alert.alert('Success', 'Auto-trading resumed');
    } catch (error) {
      Alert.alert('Error', 'Failed to resume trading');
    } finally {
      setLoading(false);
    }
  };

  const updateRiskSettings = async () => {
    const posSize = parseFloat(positionSize);
    const maxTrades = parseInt(maxConcurrentTrades);
    const maxInv = parseFloat(maxInvestment);
    const lev = parseInt(leverage);

    if (isNaN(posSize) || posSize < 1) {
      Alert.alert('Error', 'Position size must be at least $1');
      return;
    }

    if (isNaN(maxTrades) || maxTrades < 1 || maxTrades > 50) {
      Alert.alert('Error', 'Max concurrent trades must be between 1-50');
      return;
    }

    if (isNaN(maxInv) || maxInv < 10) {
      Alert.alert('Error', 'Max investment must be at least $10');
      return;
    }

    if (isNaN(lev) || lev < 1 || lev > 125) {
      Alert.alert('Error', 'Leverage must be between 1-125x');
      return;
    }

    try {
      setLoading(true);
      await userAPI.updateRisk(user.user_id, {
        default_position_size: posSize,
        max_concurrent_trades: maxTrades,
        default_leverage: lev,
      });
      await userAPI.updateDCA(user.user_id, {
        max_investment: maxInv,
      });
      await refreshUser();
      Alert.alert('Success', 'Capital settings updated');
    } catch (error) {
      Alert.alert('Error', 'Failed to update capital settings');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSettings();
  }, [user]);

  const loadSettings = () => {
    if (user) {
      setMode(user.general_settings?.mode || 'demo');
      setAutoTradeEnabled(user.trading_preferences?.auto_trade_enabled ?? false);
      setPositionSize((user.risk_settings?.default_position_size || 5.0).toString());
      setMaxConcurrentTrades((user.risk_settings?.max_concurrent_trades || 3).toString());
      setLeverage((user.risk_settings?.default_leverage || 10).toString());
      setMaxInvestment((user.dca_settings?.max_investment || 100.0).toString());
      setAutoFollow(user.strategy_settings?.auto_follow ?? true);
      setAutoStopOnSignals(user.strategy_settings?.auto_stop_on_signals ?? true);
      setTargetBasedTP(user.strategy_settings?.target_based_tp ?? true);
      setNotifyOnEntry(user.trading_preferences?.notify_on_entry ?? true);
      setNotifyOnTP(user.trading_preferences?.notify_on_tp ?? true);
      setNotifyOnSL(user.trading_preferences?.notify_on_sl ?? true);
      setNotifyOnDCA(user.trading_preferences?.notify_on_dca ?? true);
    }
  };

  const updateGeneralSettings = async (newMode) => {
    try {
      setLoading(true);
      await userAPI.updateGeneral(user.user_id, { mode: newMode });
      setMode(newMode);
      await refreshUser();
      Alert.alert('Success', `Switched to ${newMode.toUpperCase()} mode`);
    } catch (error) {
      Alert.alert('Error', 'Failed to update settings');
    } finally {
      setLoading(false);
    }
  };

  const updateStrategySettings = async (setting, value) => {
    try {
      setLoading(true);
      await userAPI.updateStrategy(user.user_id, { [setting]: value });
      await refreshUser();
    } catch (error) {
      Alert.alert('Error', 'Failed to update strategy settings');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Logout', style: 'destructive', onPress: logout },
      ]
    );
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Account Section */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Account</Text>
        
        <View style={styles.infoCard}>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Name</Text>
            <Text style={styles.infoValue}>{user?.full_name || 'N/A'}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Email</Text>
            <Text style={styles.infoValue}>{user?.email || 'N/A'}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Plan</Text>
            <Text style={[styles.infoValue, styles.planText]}>
              {user?.plan?.toUpperCase() || 'FREE'}
            </Text>
          </View>
        </View>
      </View>

      {/* Auto-Trading Control */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Auto-Trading Control</Text>
        
        <View style={styles.card}>
          {autoTradeEnabled || !tradingPaused ? (
            <TouchableOpacity
              style={[styles.controlButton, styles.pauseButton]}
              onPress={handlePauseTrading}
              disabled={loading}
            >
              <Text style={styles.controlButtonIcon}>⏸️</Text>
              <View style={styles.controlButtonText}>
                <Text style={styles.controlButtonTitle}>Pause Auto-Trading</Text>
                <Text style={styles.controlButtonDesc}>
                  Stop automated trading to withdraw profits safely
                </Text>
              </View>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              style={[styles.controlButton, styles.resumeButton]}
              onPress={handleResumeTrading}
              disabled={loading}
            >
              <Text style={styles.controlButtonIcon}>▶️</Text>
              <View style={styles.controlButtonText}>
                <Text style={styles.controlButtonTitle}>Resume Auto-Trading</Text>
                <Text style={styles.controlButtonDesc}>
                  Trading is currently paused
                </Text>
              </View>
            </TouchableOpacity>
          )}
          
          {tradingPaused && (
            <View style={styles.pausedBanner}>
              <Text style={styles.pausedText}>
                🔴 Auto-trading is paused. Your positions remain open.
              </Text>
            </View>
          )}
        </View>
      </View>

      {/* Trading Mode */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Trading Mode</Text>
        
        <View style={styles.card}>
          <View style={styles.modeContainer}>
            <TouchableOpacity
              style={[styles.modeButton, mode === 'demo' && styles.modeButtonActive]}
              onPress={() => updateGeneralSettings('demo')}
              disabled={loading}
            >
              <Text style={[styles.modeText, mode === 'demo' && styles.modeTextActive]}>
                DEMO
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.modeButton, mode === 'live' && styles.modeButtonActive]}
              onPress={() => updateGeneralSettings('live')}
              disabled={loading}
            >
              <Text style={[styles.modeText, mode === 'live' && styles.modeTextActive]}>
                LIVE
              </Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.modeWarning}>
            {mode === 'demo' 
              ? '📊 Demo mode uses virtual funds for testing'
              : '⚠️ Live mode uses real funds - trade carefully!'}
          </Text>
        </View>
      </View>

      {/* Capital & Position Size Settings */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Capital Allocation</Text>
        
        <View style={styles.card}>
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Position Size per Trade (USDT)</Text>
            <TextInput
              style={styles.input}
              placeholder="5.0"
              placeholderTextColor={COLORS.textMuted}
              keyboardType="numeric"
              value={positionSize}
              onChangeText={setPositionSize}
            />
            <Text style={styles.inputHint}>Base amount allocated to each trade</Text>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Max Concurrent Trades</Text>
            <TextInput
              style={styles.input}
              placeholder="3"
              placeholderTextColor={COLORS.textMuted}
              keyboardType="numeric"
              value={maxConcurrentTrades}
              onChangeText={setMaxConcurrentTrades}
            />
            <Text style={styles.inputHint}>Maximum number of trades open at once (1-20)</Text>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Leverage</Text>
            <TextInput
              style={styles.input}
              placeholder="10"
              placeholderTextColor={COLORS.textMuted}
              keyboardType="numeric"
              value={leverage}
              onChangeText={setLeverage}
            />
            <Text style={styles.inputHint}>Trading leverage multiplier (1-125x)</Text>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Max Investment per Symbol (USDT)</Text>
            <TextInput
              style={styles.input}
              placeholder="100.0"
              placeholderTextColor={COLORS.textMuted}
              keyboardType="numeric"
              value={maxInvestment}
              onChangeText={setMaxInvestment}
            />
            <Text style={styles.inputHint}>Maximum total investment including DCA orders</Text>
          </View>

          <TouchableOpacity
            style={styles.saveButton}
            onPress={updateRiskSettings}
            disabled={loading}
          >
            <Text style={styles.saveButtonText}>
              {loading ? 'Saving...' : 'Save Capital Settings'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Strategy Settings */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Strategy</Text>
        
        <View style={styles.card}>
          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>Auto Follow Signals</Text>
              <Text style={styles.settingDesc}>Automatically enter trades from signals</Text>
            </View>
            <Switch
              value={autoFollow}
              onValueChange={(value) => {
                setAutoFollow(value);
                updateStrategySettings('auto_follow', value);
              }}
              trackColor={{ false: COLORS.border, true: COLORS.tealBright }}
              thumbColor={autoFollow ? COLORS.textPrimary : COLORS.textMuted}
            />
          </View>

          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>Auto-Stop on Signals</Text>
              <Text style={styles.settingDesc}>Close positions when signals are cancelled</Text>
            </View>
            <Switch
              value={autoStopOnSignals}
              onValueChange={(value) => {
                setAutoStopOnSignals(value);
                updateStrategySettings('auto_stop_on_signals', value);
              }}
              trackColor={{ false: COLORS.border, true: COLORS.tealBright }}
              thumbColor={autoStopOnSignals ? COLORS.textPrimary : COLORS.textMuted}
            />
          </View>

          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>Target-Based Take Profit</Text>
              <Text style={styles.settingDesc}>Progressive TP at each target level</Text>
            </View>
            <Switch
              value={targetBasedTP}
              onValueChange={(value) => {
                setTargetBasedTP(value);
                updateStrategySettings('target_based_tp', value);
              }}
              trackColor={{ false: COLORS.border, true: COLORS.tealBright }}
              thumbColor={targetBasedTP ? COLORS.textPrimary : COLORS.textMuted}
            />
          </View>
        </View>
      </View>

      {/* Notifications */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Notifications</Text>
        
        <View style={styles.card}>
          <View style={styles.settingRow}>
            <Text style={styles.settingLabel}>Entry Notifications</Text>
            <Switch
              value={notifyOnEntry}
              onValueChange={(value) => {
                setNotifyOnEntry(value);
                updateNotificationSettings('notify_on_entry', value);
              }}
              trackColor={{ false: COLORS.border, true: COLORS.tealBright }}
              thumbColor={notifyOnEntry ? COLORS.textPrimary : COLORS.textMuted}
            />
          </View>

          <View style={styles.settingRow}>
            <Text style={styles.settingLabel}>Take Profit Notifications</Text>
            <Switch
              value={notifyOnTP}
              onValueChange={(value) => {
                setNotifyOnTP(value);
                updateNotificationSettings('notify_on_tp', value);
              }}
              trackColor={{ false: COLORS.border, true: COLORS.tealBright }}
              thumbColor={notifyOnTP ? COLORS.textPrimary : COLORS.textMuted}
            />
          </View>

          <View style={styles.settingRow}>
            <Text style={styles.settingLabel}>Stop Loss Notifications</Text>
            <Switch
              value={notifyOnSL}
              onValueChange={(value) => {
                setNotifyOnSL(value);
                updateNotificationSettings('notify_on_sl', value);
              }}
              trackColor={{ false: COLORS.border, true: COLORS.tealBright }}
              thumbColor={notifyOnSL ? COLORS.textPrimary : COLORS.textMuted}
            />
          </View>

          <View style={styles.settingRow}>
            <Text style={styles.settingLabel}>DCA Notifications</Text>
            <Switch
              value={notifyOnDCA}
              onValueChange={(value) => {
                setNotifyOnDCA(value);
                updateNotificationSettings('notify_on_dca', value);
              }}
              trackColor={{ false: COLORS.border, true: COLORS.tealBright }}
              thumbColor={notifyOnDCA ? COLORS.textPrimary : COLORS.textMuted}
            />
          </View>
        </View>
      </View>

      {/* Referral Rewards */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Earnings</Text>
        
        <TouchableOpacity 
          style={styles.rewardsButton} 
          onPress={() => navigation.navigate('Referrals')}
        >
          <Text style={styles.rewardsIcon}>🎁</Text>
          <View style={styles.rewardsTextContainer}>
            <Text style={styles.rewardsTitle}>My Referrals</Text>
            <Text style={styles.rewardsSubtitle}>Share code & earn $10 per friend</Text>
          </View>
          <Text style={styles.rewardsArrow}>→</Text>
        </TouchableOpacity>

        <View style={{ height: 12 }} />
        
        <TouchableOpacity 
          style={styles.rewardsButton} 
          onPress={() => navigation.navigate('Rewards')}
        >
          <Text style={styles.rewardsIcon}>💰</Text>
          <View style={styles.rewardsTextContainer}>
            <Text style={styles.rewardsTitle}>Referral Rewards</Text>
            <Text style={styles.rewardsSubtitle}>View your earnings & withdraw</Text>
          </View>
          <Text style={styles.rewardsArrow}>→</Text>
        </TouchableOpacity>
      </View>

      {/* User Guide */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Help & Support</Text>
        
        <TouchableOpacity 
          style={styles.rewardsButton} 
          onPress={() => navigation.navigate('HelpResources')}
        >
          <Text style={styles.rewardsIcon}>📚</Text>
          <View style={styles.rewardsTextContainer}>
            <Text style={styles.rewardsTitle}>Help & Resources</Text>
            <Text style={styles.rewardsSubtitle}>Guides, tutorials, and support</Text>
          </View>
          <Text style={styles.rewardsArrow}>→</Text>
        </TouchableOpacity>

        <View style={{ height: 12 }} />

        <TouchableOpacity 
          style={styles.rewardsButton} 
          onPress={() => navigation.navigate('UserGuide')}
        >
          <Text style={styles.rewardsIcon}>📖</Text>
          <View style={styles.rewardsTextContainer}>
            <Text style={styles.rewardsTitle}>User Guide</Text>
            <Text style={styles.rewardsSubtitle}>Learn how to use VerzekAutoTrader</Text>
          </View>
          <Text style={styles.rewardsArrow}>→</Text>
        </TouchableOpacity>
      </View>

      {/* Logout */}
      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Text style={styles.logoutText}>Logout</Text>
      </TouchableOpacity>

      <View style={styles.version}>
        <Text style={styles.versionText}>VerzekAutoTrader v1.0.0</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bgDark,
  },
  content: {
    padding: 12,
    paddingBottom: 12,
  },
  section: {
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 10,
  },
  card: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  infoCard: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  infoLabel: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  infoValue: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.textPrimary,
  },
  planText: {
    color: COLORS.goldDark,
  },
  modeContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 12,
  },
  modeButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: COLORS.tealDark,
    alignItems: 'center',
  },
  modeButtonActive: {
    backgroundColor: COLORS.goldDark,
  },
  modeText: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.textSecondary,
  },
  modeTextActive: {
    color: COLORS.textPrimary,
  },
  modeWarning: {
    fontSize: 12,
    color: COLORS.textSecondary,
    textAlign: 'center',
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  settingInfo: {
    flex: 1,
    marginRight: 16,
  },
  settingLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 4,
  },
  settingDesc: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  rewardsButton: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
    flexDirection: 'row',
    alignItems: 'center',
  },
  rewardsIcon: {
    fontSize: 28,
    marginRight: 12,
  },
  rewardsTextContainer: {
    flex: 1,
  },
  rewardsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 2,
  },
  rewardsSubtitle: {
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  rewardsArrow: {
    fontSize: 20,
    color: COLORS.textSecondary,
  },
  logoutButton: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.goldDark,
    marginTop: 8,
  },
  logoutText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.goldDark,
  },
  controlButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  pauseButton: {
    backgroundColor: `${COLORS.goldDark}20`,
    borderWidth: 2,
    borderColor: COLORS.goldDark,
  },
  resumeButton: {
    backgroundColor: `${COLORS.tealBright}20`,
    borderWidth: 2,
    borderColor: COLORS.tealBright,
  },
  controlButtonIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  controlButtonText: {
    flex: 1,
  },
  controlButtonTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 4,
  },
  controlButtonDesc: {
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  pausedBanner: {
    backgroundColor: `#EF444420`,
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#EF4444',
  },
  pausedText: {
    fontSize: 14,
    color: '#EF4444',
    fontWeight: '600',
    textAlign: 'center',
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 8,
  },
  input: {
    backgroundColor: COLORS.bgDark,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: COLORS.textPrimary,
    marginBottom: 6,
  },
  inputHint: {
    fontSize: 12,
    color: COLORS.textSecondary,
    fontStyle: 'italic',
  },
  saveButton: {
    backgroundColor: COLORS.tealBright,
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 8,
  },
  saveButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.bgDark,
  },
  version: {
    alignItems: 'center',
    marginTop: 24,
    marginBottom: 32,
  },
  versionText: {
    fontSize: 12,
    color: COLORS.textMuted,
  },
});
