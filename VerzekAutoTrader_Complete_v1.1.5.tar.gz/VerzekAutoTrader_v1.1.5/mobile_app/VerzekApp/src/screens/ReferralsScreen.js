import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Share,
  Alert,
  ActivityIndicator,
  Clipboard,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { referralAPI } from '../services/api';
import { COLORS } from '../constants/colors';

export default function ReferralsScreen() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [referralData, setReferralData] = useState(null);

  useEffect(() => {
    loadReferralData();
  }, []);

  const loadReferralData = async () => {
    if (!user?.user_id) return;
    
    try {
      setLoading(true);
      const response = await referralAPI.getReferrals(user.user_id);
      setReferralData(response.data);
    } catch (error) {
      console.error('Error loading referrals:', error);
      Alert.alert('Error', 'Failed to load referral data');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    loadReferralData();
  };

  const copyReferralCode = () => {
    if (referralData?.referral_code) {
      Clipboard.setString(referralData.referral_code);
      Alert.alert('Copied!', 'Referral code copied to clipboard');
    }
  };

  const shareReferralCode = async () => {
    if (!referralData?.referral_code) return;

    try {
      await Share.share({
        message: `Join Verzek Auto Trader and get automated crypto trading! Use my referral code: ${referralData.referral_code}\n\nDownload the app and start trading today! 🚀`,
        title: 'Join Verzek Auto Trader',
      });
    } catch (error) {
      console.error('Share error:', error);
    }
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={COLORS.tealBright} />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>My Referrals</Text>
        <Text style={styles.headerSubtitle}>
          Earn $10 for every friend who joins!
        </Text>
      </View>

      {/* Referral Code Card */}
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <Ionicons name="gift" size={24} color={COLORS.gold} />
          <Text style={styles.cardTitle}>Your Referral Code</Text>
        </View>
        
        <View style={styles.codeContainer}>
          <Text style={styles.codeText}>
            {referralData?.referral_code || 'Loading...'}
          </Text>
        </View>

        <View style={styles.buttonRow}>
          <TouchableOpacity style={styles.actionButton} onPress={copyReferralCode}>
            <Ionicons name="copy-outline" size={20} color={COLORS.textPrimary} />
            <Text style={styles.actionButtonText}>Copy</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={[styles.actionButton, styles.actionButtonPrimary]} 
            onPress={shareReferralCode}
          >
            <Ionicons name="share-social-outline" size={20} color={COLORS.textPrimary} />
            <Text style={styles.actionButtonText}>Share</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Stats Card */}
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{referralData?.total_referrals || 0}</Text>
          <Text style={styles.statLabel}>Total Referrals</Text>
        </View>

        <View style={styles.statCard}>
          <Text style={styles.statValue}>
            ${(referralData?.total_earnings || 0).toFixed(2)}
          </Text>
          <Text style={styles.statLabel}>Total Earnings</Text>
        </View>
      </View>

      {/* How It Works */}
      <View style={styles.card}>
        <Text style={styles.sectionTitle}>How It Works</Text>
        <View style={styles.stepContainer}>
          <View style={styles.step}>
            <View style={styles.stepNumber}>
              <Text style={styles.stepNumberText}>1</Text>
            </View>
            <Text style={styles.stepText}>Share your referral code with friends</Text>
          </View>

          <View style={styles.step}>
            <View style={styles.stepNumber}>
              <Text style={styles.stepNumberText}>2</Text>
            </View>
            <Text style={styles.stepText}>
              They register using your code
            </Text>
          </View>

          <View style={styles.step}>
            <View style={styles.stepNumber}>
              <Text style={styles.stepNumberText}>3</Text>
            </View>
            <Text style={styles.stepText}>
              You earn $10 bonus for each successful referral
            </Text>
          </View>

          <View style={styles.step}>
            <View style={styles.stepNumber}>
              <Text style={styles.stepNumberText}>4</Text>
            </View>
            <Text style={styles.stepText}>
              Contact @VerzekSupport on Telegram to claim your earnings
            </Text>
          </View>
        </View>
      </View>

      {/* Referral List */}
      {referralData?.referrals && referralData.referrals.length > 0 && (
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Your Referrals</Text>
          {referralData.referrals.map((referral, index) => (
            <View key={index} style={styles.referralItem}>
              <View style={styles.referralIcon}>
                <Ionicons name="person" size={20} color={COLORS.tealBright} />
              </View>
              <View style={styles.referralInfo}>
                <Text style={styles.referralName}>{referral.name}</Text>
                <Text style={styles.referralPlan}>{referral.subscription_plan}</Text>
              </View>
              <Text style={styles.referralBonus}>+${referral.bonus_earned}</Text>
            </View>
          ))}
        </View>
      )}

      <TouchableOpacity style={styles.refreshButton} onPress={handleRefresh}>
        <Ionicons name="refresh" size={20} color={COLORS.tealBright} />
        <Text style={styles.refreshButtonText}>Refresh Data</Text>
      </TouchableOpacity>

      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Questions? Contact @VerzekSupport on Telegram
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bgDark,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.bgDark,
  },
  header: {
    padding: 20,
    paddingTop: 60,
    backgroundColor: COLORS.bgCard,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.gold,
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: COLORS.textSecondary,
  },
  card: {
    backgroundColor: COLORS.bgCard,
    margin: 16,
    padding: 20,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginLeft: 8,
  },
  codeContainer: {
    backgroundColor: COLORS.bgDark,
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 2,
    borderColor: COLORS.tealBright,
  },
  codeText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.gold,
    letterSpacing: 2,
  },
  buttonRow: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 8,
    backgroundColor: COLORS.bgDark,
    borderWidth: 1,
    borderColor: COLORS.border,
    gap: 8,
  },
  actionButtonPrimary: {
    backgroundColor: COLORS.tealBright,
    borderColor: COLORS.tealBright,
  },
  actionButtonText: {
    color: COLORS.textPrimary,
    fontWeight: '600',
    fontSize: 14,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: COLORS.bgCard,
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  statValue: {
    fontSize: 32,
    fontWeight: 'bold',
    color: COLORS.gold,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 16,
  },
  stepContainer: {
    gap: 16,
  },
  step: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  stepNumber: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: COLORS.tealBright,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepNumberText: {
    color: COLORS.textPrimary,
    fontWeight: 'bold',
    fontSize: 14,
  },
  stepText: {
    flex: 1,
    color: COLORS.textSecondary,
    fontSize: 14,
    lineHeight: 20,
    paddingTop: 4,
  },
  referralItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: COLORS.bgDark,
    borderRadius: 8,
    marginBottom: 8,
  },
  referralIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.bgCard,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  referralInfo: {
    flex: 1,
  },
  referralName: {
    color: COLORS.textPrimary,
    fontWeight: '600',
    fontSize: 14,
    marginBottom: 2,
  },
  referralPlan: {
    color: COLORS.textSecondary,
    fontSize: 12,
  },
  referralBonus: {
    color: COLORS.gold,
    fontWeight: 'bold',
    fontSize: 16,
  },
  refreshButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 8,
    backgroundColor: COLORS.bgCard,
    borderWidth: 1,
    borderColor: COLORS.tealBright,
    gap: 8,
  },
  refreshButtonText: {
    color: COLORS.tealBright,
    fontWeight: '600',
    fontSize: 14,
  },
  footer: {
    padding: 20,
    alignItems: 'center',
  },
  footerText: {
    color: COLORS.textMuted,
    fontSize: 12,
    textAlign: 'center',
  },
});
