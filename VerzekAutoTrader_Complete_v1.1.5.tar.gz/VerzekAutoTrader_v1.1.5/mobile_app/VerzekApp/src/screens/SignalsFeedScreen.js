import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  RefreshControl,
  Alert,
  AppState,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { signalsAPI } from '../services/api';
import { COLORS } from '../constants/colors';

export default function SignalsFeedScreen() {
  const [signals, setSignals] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [livePrices, setLivePrices] = useState({});
  const pollingIntervalRef = useRef(null);
  const pricePollingRef = useRef(null);
  const appState = useRef(AppState.currentState);

  useEffect(() => {
    loadSignals();
    startPolling();
    startPricePolling();

    const subscription = AppState.addEventListener('change', nextAppState => {
      if (
        appState.current.match(/inactive|background/) &&
        nextAppState === 'active'
      ) {
        loadSignals();
        fetchLivePrices();
      }
      appState.current = nextAppState;
    });

    return () => {
      stopPolling();
      stopPricePolling();
      subscription.remove();
    };
  }, []);

  useFocusEffect(
    React.useCallback(() => {
      loadSignals();
      startPolling();
      startPricePolling();
      
      return () => {
        stopPolling();
        stopPricePolling();
      };
    }, [])
  );

  const startPolling = () => {
    stopPolling();
    pollingIntervalRef.current = setInterval(() => {
      loadSignalsSilently();
    }, 10000);
  };

  const stopPolling = () => {
    if (pollingIntervalRef.current) {
      clearInterval(pollingIntervalRef.current);
      pollingIntervalRef.current = null;
    }
  };

  const startPricePolling = () => {
    stopPricePolling();
    fetchLivePrices();
    pricePollingRef.current = setInterval(() => {
      fetchLivePrices();
    }, 5000);
  };

  const stopPricePolling = () => {
    if (pricePollingRef.current) {
      clearInterval(pricePollingRef.current);
      pricePollingRef.current = null;
    }
  };

  const fetchLivePrices = async () => {
    try {
      const symbols = signals.map(s => s.symbol).filter(Boolean);
      if (symbols.length === 0) return;

      const prices = {};
      for (const symbol of symbols) {
        try {
          const response = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${symbol}`);
          const data = await response.json();
          if (data.price) {
            prices[symbol] = parseFloat(data.price);
          }
        } catch (e) {
          console.log(`Failed to fetch price for ${symbol}`);
        }
      }
      setLivePrices(prices);
    } catch (error) {
      console.error('Error fetching live prices:', error);
    }
  };

  const loadSignals = async () => {
    try {
      const response = await signalsAPI.getSignals();
      const rawSignals = response.data.signals || [];
      
      const parsedSignals = rawSignals.map((sig, index) => {
        const parsed = parseSignalText(sig.text);
        return {
          id: sig.id || `signal_${index}`,
          ...parsed,
          timestamp: sig.timestamp,
          raw_text: sig.text,
        };
      }).filter(s => s.symbol && s.direction);
      
      setSignals(parsedSignals);
    } catch (error) {
      console.error('Error loading signals:', error);
      Alert.alert('Error', 'Failed to load signals. Please try again.');
      setSignals([]);
    } finally {
      setLoading(false);
    }
  };

  const loadSignalsSilently = async () => {
    try {
      const response = await signalsAPI.getSignals();
      const rawSignals = response.data.signals || [];
      
      const parsedSignals = rawSignals.map((sig, index) => {
        const parsed = parseSignalText(sig.text);
        return {
          id: sig.id || `signal_${index}`,
          ...parsed,
          timestamp: sig.timestamp,
          raw_text: sig.text,
        };
      }).filter(s => s.symbol && s.direction);
      
      setSignals(parsedSignals);
    } catch (error) {
      console.error('Silent signal refresh failed:', error);
    }
  };

  const parseSignalText = (text) => {
    const upper = text.toUpperCase();
    
    const symbolMatch = upper.match(/([A-Z]{3,5})[-\/]?USDT/);
    const symbol = symbolMatch ? `${symbolMatch[1]}USDT` : null;
    
    const direction = upper.includes('LONG') ? 'LONG' : upper.includes('SHORT') ? 'SHORT' : null;
    
    const entryMatch = upper.match(/ENTRY[:\s]*([0-9]+(?:\.[0-9]+)?)/);
    const entry = entryMatch ? parseFloat(entryMatch[1]) : null;
    
    const targetMatches = upper.matchAll(/TARGET[S]?\s*(\d+)?[:\s]*([0-9]+(?:\.[0-9]+)?)/g);
    const targets = Array.from(targetMatches).map(m => parseFloat(m[2]));
    
    const slMatch = upper.match(/STOP\s*(?:LOSS)?[:\s]*([0-9]+(?:\.[0-9]+)?)/);
    const stop_loss = slMatch ? parseFloat(slMatch[1]) : null;
    
    const levMatch = upper.match(/(?:LEV|LEVERAGE)[:\s]*X?([0-9]+)/);
    const leverage = levMatch ? parseInt(levMatch[1]) : null;
    
    const status = upper.includes('CANCEL') || upper.includes('CLOSED') ? 'closed' : 'active';
    
    return {
      symbol,
      direction,
      entry,
      targets,
      stop_loss,
      leverage,
      status,
    };
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadSignals();
    setRefreshing(false);
  };

  const getDirectionColor = (direction) => {
    return direction === 'LONG' ? COLORS.tealBright : COLORS.goldDark;
  };

  const getStatusColor = (status) => {
    return status === 'active' ? COLORS.gold : COLORS.textMuted;
  };

  const formatTime = (timestamp) => {
    try {
      // Parse timestamp and treat it as UTC (server timezone)
      // Format: "2025-10-24 07:53:37"
      const date = new Date(timestamp + ' UTC');
      const now = new Date();
      const diff = now - date;
      const minutes = Math.floor(diff / 60000);
      const hours = Math.floor(diff / 3600000);
      
      if (minutes < 1) return 'Just now';
      if (minutes < 60) return `${minutes}m ago`;
      if (hours < 24) return `${hours}h ago`;
      return date.toLocaleDateString();
    } catch (e) {
      return timestamp;
    }
  };

  const calculateTradeProgress = (signal, currentPrice) => {
    if (!currentPrice || !signal.entry) return null;

    const isLong = signal.direction === 'LONG';
    const entry = signal.entry;
    const sl = signal.stop_loss;
    
    const pnlPercent = isLong 
      ? ((currentPrice - entry) / entry) * 100 * (signal.leverage || 1)
      : ((entry - currentPrice) / entry) * 100 * (signal.leverage || 1);

    const highestTarget = signal.targets && signal.targets.length > 0 
      ? Math.max(...signal.targets) 
      : null;

    let progressPercent = 0;
    let currentLevel = 'Entry';
    let targetReached = 0;

    if (sl && highestTarget) {
      const totalRange = Math.abs(highestTarget - sl);
      const currentProgress = Math.abs(currentPrice - sl);
      progressPercent = Math.min(100, Math.max(0, (currentProgress / totalRange) * 100));
      
      if (signal.targets) {
        for (let i = 0; i < signal.targets.length; i++) {
          const target = signal.targets[i];
          const targetReachedCheck = isLong ? currentPrice >= target : currentPrice <= target;
          if (targetReachedCheck) {
            targetReached = i + 1;
            currentLevel = `Target ${i + 1}`;
          }
        }
      }
      
      const slHit = isLong ? currentPrice <= sl : currentPrice >= sl;
      if (slHit) {
        currentLevel = 'SL Hit';
      }
    }

    return {
      pnlPercent,
      progressPercent,
      currentLevel,
      targetReached,
      currentPrice
    };
  };

  const renderSignal = ({ item }) => {
    const currentPrice = livePrices[item.symbol];
    const progress = calculateTradeProgress(item, currentPrice);

    return (
      <View style={styles.signalCard}>
        <View style={styles.signalHeader}>
          <View style={styles.symbolContainer}>
            <Text style={styles.symbol}>{item.symbol || 'UNKNOWN'}</Text>
            <View style={[styles.directionBadge, { backgroundColor: getDirectionColor(item.direction) }]}>
              <Text style={styles.directionText}>
                {item.direction === 'LONG' ? '↑' : '↓'} {item.direction} {item.leverage ? `x${item.leverage}` : ''}
              </Text>
            </View>
          </View>
          <View style={styles.headerRight}>
            {progress && (
              <View style={styles.pnlBadge}>
                <Text style={[styles.pnlText, { color: progress.pnlPercent >= 0 ? COLORS.tealBright : '#FF4444' }]}>
                  {progress.pnlPercent >= 0 ? '+' : ''}{progress.pnlPercent.toFixed(2)}%
                </Text>
              </View>
            )}
            <Text style={styles.timestamp}>{formatTime(item.timestamp)}</Text>
            {progress && (
              <View style={[styles.statusBadge, { backgroundColor: progress.targetReached > 0 ? '#10B981' : '#6B7280' }]}>
                <Text style={styles.statusBadgeText}>
                  {progress.targetReached > 0 ? `Target ${progress.targetReached} ✓` : 'In progress'}
                </Text>
              </View>
            )}
          </View>
        </View>

      {item.entry && (
        <View style={styles.priceSection}>
          <View style={styles.priceItem}>
            <Text style={styles.priceLabel}>Entry</Text>
            <Text style={styles.priceValue}>${item.entry.toLocaleString()}</Text>
          </View>
          {item.stop_loss && (
            <View style={styles.priceItem}>
              <Text style={styles.priceLabel}>Stop Loss</Text>
              <Text style={[styles.priceValue, { color: COLORS.goldDark }]}>
                ${item.stop_loss.toLocaleString()}
              </Text>
            </View>
          )}
        </View>
      )}

      {item.targets && item.targets.length > 0 && (
        <View style={styles.targetsSection}>
          <Text style={styles.targetsLabel}>Targets:</Text>
          <View style={styles.targetsContainer}>
            {item.targets.map((target, index) => (
              <View key={index} style={styles.targetBadge}>
                <Text style={styles.targetText}>
                  {index + 1}: ${target.toLocaleString()}
                </Text>
              </View>
            ))}
          </View>
        </View>
      )}

      {progress && item.stop_loss && item.targets && item.targets.length > 0 && (
        <View style={styles.progressSection}>
          <View style={styles.progressBarContainer}>
            <View style={styles.progressBar}>
              <View style={[styles.progressFill, { 
                width: `${progress.progressPercent}%`,
                backgroundColor: progress.pnlPercent >= 0 ? COLORS.tealBright : '#FF4444'
              }]} />
            </View>
            
            <View style={styles.progressMarkers}>
              <View style={styles.markerGroup}>
                <View style={styles.marker} />
                <Text style={styles.markerLabel}>SL</Text>
              </View>
              <View style={styles.markerGroup}>
                <View style={[styles.marker, styles.entryMarker]} />
                <Text style={styles.markerLabel}>Entry</Text>
              </View>
              {item.targets.slice(0, 5).map((_, index) => (
                <View key={index} style={styles.markerGroup}>
                  <View style={[styles.marker, index < progress.targetReached && styles.reachedMarker]} />
                  <Text style={styles.markerLabel}>T{index + 1}</Text>
                </View>
              ))}
            </View>
            
            {progress.currentPrice && (
              <View style={[styles.priceIndicator, { left: `${Math.min(95, Math.max(5, progress.progressPercent))}%` }]}>
                <View style={[styles.priceIndicatorLine, { backgroundColor: progress.pnlPercent >= 0 ? COLORS.tealBright : '#FF4444' }]} />
                <View style={[styles.priceIndicatorBox, { 
                  borderColor: progress.pnlPercent >= 0 ? COLORS.tealBright : '#FF4444',
                  backgroundColor: COLORS.bgDark
                }]}>
                  <Text style={[styles.priceIndicatorText, { color: progress.pnlPercent >= 0 ? COLORS.tealBright : '#FF4444' }]}>
                    {progress.currentPrice.toFixed(4)}
                  </Text>
                </View>
              </View>
            )}
          </View>
        </View>
      )}

      <View style={styles.statusBar}>
        <View style={[styles.statusDot, { backgroundColor: getStatusColor(item.status) }]} />
        <Text style={[styles.statusText, { color: getStatusColor(item.status) }]}>
          {item.status ? item.status.toUpperCase() : 'UNKNOWN'}
        </Text>
      </View>
    </View>
    );
  };

  const renderEmpty = () => (
    <View style={styles.emptyContainer}>
      <Text style={styles.emptyIcon}>📡</Text>
      <Text style={styles.emptyTitle}>No Signals Yet</Text>
      <Text style={styles.emptyText}>
        Trading signals will appear here when broadcast
      </Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={signals}
        renderItem={renderSignal}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.gold} />
        }
        ListEmptyComponent={renderEmpty}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bgDark,
  },
  listContent: {
    padding: 12,
  },
  signalCard: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  signalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  symbolContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  symbol: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginRight: 12,
  },
  directionBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  directionText: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.bgDark,
  },
  leverage: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.gold,
    textAlign: 'right',
  },
  timestamp: {
    fontSize: 12,
    color: COLORS.textMuted,
    marginTop: 4,
    textAlign: 'right',
  },
  priceSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  priceItem: {
    flex: 1,
  },
  priceLabel: {
    fontSize: 12,
    color: COLORS.textMuted,
    marginBottom: 4,
  },
  priceValue: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.tealBright,
  },
  targetsSection: {
    marginBottom: 12,
  },
  targetsLabel: {
    fontSize: 12,
    color: COLORS.textMuted,
    marginBottom: 8,
  },
  targetsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  targetBadge: {
    backgroundColor: COLORS.tealDark,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
  },
  targetText: {
    fontSize: 12,
    color: COLORS.textPrimary,
    fontWeight: '500',
  },
  statusBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 50,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    textAlign: 'center',
  },
  headerRight: {
    alignItems: 'flex-end',
  },
  pnlBadge: {
    marginBottom: 4,
  },
  pnlText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
    marginTop: 4,
  },
  statusBadgeText: {
    fontSize: 11,
    fontWeight: '600',
    color: COLORS.textPrimary,
  },
  progressSection: {
    marginTop: 16,
    marginBottom: 12,
  },
  progressBarContainer: {
    position: 'relative',
    paddingTop: 30,
  },
  progressBar: {
    height: 8,
    backgroundColor: COLORS.border,
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  progressMarkers: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  markerGroup: {
    alignItems: 'center',
  },
  marker: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: COLORS.textMuted,
    marginBottom: 4,
  },
  entryMarker: {
    backgroundColor: COLORS.textPrimary,
  },
  reachedMarker: {
    backgroundColor: COLORS.tealBright,
  },
  markerLabel: {
    fontSize: 10,
    color: COLORS.textMuted,
    fontWeight: '500',
  },
  priceIndicator: {
    position: 'absolute',
    top: -5,
    alignItems: 'center',
    transform: [{ translateX: -20 }],
  },
  priceIndicatorLine: {
    width: 2,
    height: 20,
    marginBottom: 4,
  },
  priceIndicatorBox: {
    borderWidth: 2,
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  priceIndicatorText: {
    fontSize: 11,
    fontWeight: 'bold',
  },
});
