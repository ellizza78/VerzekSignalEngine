import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { COLORS } from '../constants/colors';

const GuideDetailScreen = ({ route }) => {
  const { topic } = route.params;

  const getDetailContent = (topicId) => {
    const content = {
      1: {
        sections: [
          {
            title: 'Welcome to VerzekAutoTrader',
            text: 'VerzekAutoTrader is an advanced DCA (Dollar Cost Averaging) auto-trading platform that monitors Telegram signals and executes trades automatically across multiple exchanges.',
          },
          {
            title: 'Quick Setup Steps',
            text: '1. Verify your email address\n2. Choose a subscription plan (FREE, PRO, or VIP)\n3. Connect your exchange accounts\n4. Configure your DCA strategy\n5. Enable auto-trading',
          },
          {
            title: 'Important',
            text: 'Always start with Demo Mode to test the system before trading with real funds.',
          },
        ],
      },
      2: {
        sections: [
          {
            title: 'Why IP Whitelisting?',
            text: 'Exchanges require you to whitelist our server IP address to ensure only authorized systems can access your API keys.',
          },
          {
            title: 'Step-by-Step',
            text: '1. Go to Exchanges tab\n2. Tap on your desired exchange (Binance, Bybit, etc.)\n3. Copy the server IP address shown\n4. Log into your exchange account\n5. Go to API Management\n6. Add the IP to your whitelist\n7. Create API keys with Futures trading permission\n8. Return to VerzekAutoTrader and enter your keys',
          },
          {
            title: 'Security Tips',
            text: '• Never share your API secret with anyone\n• Only enable necessary permissions (Futures Trading)\n• Always use ISOLATED margin, NOT Cross Margin',
          },
        ],
      },
      3: {
        sections: [
          {
            title: 'What is DCA?',
            text: 'Dollar Cost Averaging is a strategy where you enter a position in multiple steps instead of all at once. This reduces your average entry price when the market moves against you.',
          },
          {
            title: 'How VerzekAutoTrader Uses DCA',
            text: 'When a signal is received, the bot:\n1. Opens initial position at market price\n2. Places DCA orders at preset intervals below entry\n3. Averages down your cost basis\n4. Executes progressive take-profit targets\n5. Manages risk with auto-stop logic',
          },
          {
            title: 'Benefits',
            text: '• Lower average entry price\n• Reduced risk per trade\n• Automated position management\n• No emotional trading decisions',
          },
        ],
      },
      5: {
        sections: [
          {
            title: 'Earn 10% Recurring Commissions',
            text: 'Share your referral code with friends and earn 10% of their monthly subscription payments for as long as they remain subscribed.',
          },
          {
            title: 'How It Works',
            text: '1. Get your unique referral code from Settings → Referral Rewards\n2. Share the code with friends\n3. When they subscribe, you earn 10% monthly\n4. Earnings accumulate in your wallet\n5. Withdraw anytime (minimum 10 USDT)',
          },
          {
            title: 'Withdrawal Process',
            text: 'Go to Referral Rewards screen, enter your USDT (TRC20) wallet address, and request a payout. Admin will process within 24 hours.',
          },
        ],
      },
      9: {
        sections: [
          {
            title: 'Demo Mode',
            text: 'Demo mode uses virtual funds to simulate real trading without risking actual capital. Perfect for:\n• Learning the platform\n• Testing strategies\n• Verifying signal quality\n• Practicing DCA settings',
          },
          {
            title: 'Live Mode',
            text: 'Live mode executes real trades with your actual exchange funds. Before switching to live:\n• Test thoroughly in demo mode\n• Verify all settings are correct\n• Ensure you understand the risks\n• Start with small position sizes',
          },
          {
            title: 'Switching Modes',
            text: 'Go to Settings → Trading Mode and select DEMO or LIVE. A warning will appear when enabling live mode.',
          },
        ],
      },
    };

    return content[topicId] || {
      sections: [
        {
          title: 'Coming Soon',
          text: 'Detailed documentation for this topic is being prepared. Please check back later or contact support for immediate assistance.',
        },
      ],
    };
  };

  const content = getDetailContent(topic.id);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>{topic.title}</Text>
      
      {content.sections.map((section, index) => (
        <View key={index} style={styles.section}>
          <Text style={styles.sectionTitle}>{section.title}</Text>
          <Text style={styles.sectionText}>{section.text}</Text>
        </View>
      ))}

      <View style={styles.helpBox}>
        <Text style={styles.helpText}>
          💡 Still have questions? Contact our support team via Telegram for personalized assistance.
        </Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bgDark,
  },
  content: {
    padding: 20,
    paddingBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 24,
    lineHeight: 32,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.tealBright,
    marginBottom: 12,
  },
  sectionText: {
    fontSize: 15,
    color: COLORS.textPrimary,
    lineHeight: 24,
  },
  helpBox: {
    backgroundColor: `${COLORS.tealBright}1A`,
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.tealBright,
    marginTop: 12,
  },
  helpText: {
    fontSize: 14,
    color: COLORS.textPrimary,
    lineHeight: 20,
  },
});

export default GuideDetailScreen;
