import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  RefreshControl,
  Alert,
  Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../context/AuthContext';
import { userAPI, systemAPI, signalsAPI, positionsAPI } from '../services/api';
import OnboardingModal from '../components/OnboardingModal';
import { COLORS } from '../constants/colors';

export default function DashboardScreen({ navigation }) {
  const { user, logout, refreshUser } = useAuth();
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState(null);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [systemStatus, setSystemStatus] = useState(null);
  const [lastSignalTime, setLastSignalTime] = useState(null);
  const [recentPositions, setRecentPositions] = useState([]);

  useEffect(() => {
    loadUserData();
    checkFirstLogin();
    loadSystemStatus();
    loadRecentPositions();
  }, []);

  const checkFirstLogin = async () => {
    try {
      const hasSeenOnboarding = await AsyncStorage.getItem('hasSeenOnboarding');
      if (!hasSeenOnboarding) {
        setTimeout(() => setShowOnboarding(true), 500);
      }
    } catch (error) {
      console.error('Error checking first login:', error);
    }
  };

  const handleCloseOnboarding = async () => {
    try {
      await AsyncStorage.setItem('hasSeenOnboarding', 'true');
      setShowOnboarding(false);
    } catch (error) {
      console.error('Error saving onboarding state:', error);
    }
  };

  const loadUserData = async () => {
    try {
      if (user?.user_id) {
        const response = await userAPI.getUser(user.user_id);
        setStats(response.data.stats);
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };

  const loadSystemStatus = async () => {
    try {
      // Get recent signals to determine connection status
      const signalsResponse = await signalsAPI.getSignals();
      const signals = signalsResponse.data.signals || [];
      
      if (signals.length > 0) {
        const latestSignal = signals[0];
        setLastSignalTime(latestSignal.timestamp);
      }
      
      setSystemStatus({
        telegram_connected: signals.length > 0,
        backend_online: true,
      });
    } catch (error) {
      console.error('Error loading system status:', error);
      setSystemStatus({
        telegram_connected: false,
        backend_online: false,
      });
    }
  };

  const loadRecentPositions = async () => {
    try {
      if (user?.user_id) {
        const response = await positionsAPI.getUserPositions(user.user_id);
        // Get last 5 positions
        const positions = response.data.positions || [];
        setRecentPositions(positions.slice(0, 5));
      }
    } catch (error) {
      console.error('Error loading recent positions:', error);
      setRecentPositions([]);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([refreshUser(), loadUserData(), loadSystemStatus(), loadRecentPositions()]);
    setRefreshing(false);
  };

  const formatLastSignalTime = (timestamp) => {
    if (!timestamp) return 'Never';
    try {
      // Parse timestamp as UTC (server is in UTC)
      const date = new Date(timestamp + ' UTC');
      const now = new Date();
      const diff = now - date;
      const minutes = Math.floor(diff / 60000);
      const hours = Math.floor(diff / 3600000);
      
      if (minutes < 1) return 'Just now';
      if (minutes < 60) return `${minutes}m ago`;
      if (hours < 24) return `${hours}h ago`;
      return date.toLocaleDateString();
    } catch (e) {
      return 'Unknown';
    }
  };

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Logout', style: 'destructive', onPress: logout },
      ]
    );
  };

  const handleRequestTelegramAccess = async () => {
    try {
      Alert.alert(
        'Request Telegram Access',
        'This will notify our support team to add you to the TRIAL Telegram group. You will be contacted shortly at @VerzekSupport. Continue?',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Request Access',
            onPress: async () => {
              try {
                const response = await userAPI.requestTelegramAccess();
                Alert.alert(
                  'Request Sent!',
                  'Your request has been sent to @VerzekSupport. You will be added to the TRIAL Telegram group shortly. Please check your Telegram for a message from @VerzekSupport.',
                  [{ text: 'OK' }]
                );
              } catch (error) {
                Alert.alert(
                  'Error',
                  error.response?.data?.error || 'Failed to send request. Please try again.'
                );
              }
            },
          },
        ]
      );
    } catch (error) {
      console.error('Error requesting Telegram access:', error);
    }
  };

  const getPlanColor = (plan) => {
    switch (plan) {
      case 'vip': return COLORS.gold;
      case 'pro': return COLORS.tealBright;
      case 'free': return COLORS.textMuted;
      default: return COLORS.textMuted;
    }
  };

  const getPlanLabel = (plan) => {
    return plan?.toUpperCase() || 'FREE';
  };

  const getPositionStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'open': return COLORS.tealBright;
      case 'tp_hit':
      case 'target_hit': 
      case 'closed': return COLORS.gold;
      case 'sl_hit':
      case 'stopped':
      case 'liquidated': return COLORS.goldDark;
      case 'canceled': return COLORS.textMuted;
      default: return COLORS.textSecondary;
    }
  };

  const getPositionStatusLabel = (status) => {
    switch (status?.toLowerCase()) {
      case 'open': return '🟢 OPEN';
      case 'tp_hit': return '✅ TP HIT';
      case 'target_hit': return '✅ TARGET';
      case 'sl_hit': return '❌ SL HIT';
      case 'stopped': return '🛑 STOPPED';
      case 'canceled': return '⚫ CANCELED';
      case 'closed': return '✅ CLOSED';
      case 'liquidated': return '💀 LIQUIDATED';
      default: return status?.toUpperCase() || 'UNKNOWN';
    }
  };

  return (
    <>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.gold} />
        }
      >
        {/* Logo & Header */}
        <View style={styles.logoContainer}>
          <Image
            source={require('../../assets/vzk-logo.png')}
            style={styles.logo}
            resizeMode="contain"
          />
        </View>

        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Welcome back,</Text>
            <Text style={styles.name}>{user?.full_name || user?.email}</Text>
          </View>
          <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
            <Text style={styles.logoutText}>Logout</Text>
          </TouchableOpacity>
        </View>

        {/* System Status Banner */}
        {systemStatus && (
          <View style={[
            styles.statusBanner,
            { backgroundColor: systemStatus.telegram_connected ? `${COLORS.tealBright}20` : `${COLORS.goldDark}20` }
          ]}>
            <View style={styles.statusRow}>
              <View style={[
                styles.statusDot,
                { backgroundColor: systemStatus.telegram_connected ? COLORS.tealBright : COLORS.goldDark }
              ]} />
              <View style={styles.statusInfo}>
                <Text style={styles.statusTitle}>
                  {systemStatus.telegram_connected ? '🟢 Signals Connected' : '🟡 Waiting for Signals'}
                </Text>
                <Text style={styles.statusSubtitle}>
                  Last signal: {formatLastSignalTime(lastSignalTime)}
                </Text>
              </View>
            </View>
          </View>
        )}

        {/* Subscription Card */}
        <TouchableOpacity 
          style={styles.card}
          onPress={() => navigation.navigate('Subscription')}
          activeOpacity={0.7}
        >
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>Subscription</Text>
            <View style={[styles.badge, { backgroundColor: getPlanColor(user?.plan) }]}>
              <Text style={styles.badgeText}>{getPlanLabel(user?.plan)}</Text>
            </View>
          </View>
          <Text style={styles.cardSubtitle}>
            {user?.plan === 'free' ? 'Upgrade to unlock all features' : 'Active subscription'}
          </Text>
          {user?.plan_expires_at && (
            <Text style={styles.expiryText}>
              Expires: {new Date(user.plan_expires_at).toLocaleDateString()}
            </Text>
          )}
          <View style={styles.upgradeButton}>
            <Text style={styles.upgradeButtonText}>
              {user?.plan === 'free' ? '🚀 Upgrade Now' : '⚙️ Manage Plan'}
            </Text>
            <Text style={styles.upgradeArrow}>›</Text>
          </View>
        </TouchableOpacity>

        {/* Telegram Access Request Card - Only for TRIAL users */}
        {user?.plan === 'trial' && (
          <View style={styles.telegramCard}>
            <Text style={styles.telegramCardTitle}>📱 Telegram Group Access</Text>
            <Text style={styles.telegramCardText}>
              As a TRIAL member, you can request access to our exclusive Telegram group for signals and support.
            </Text>
            <TouchableOpacity 
              style={styles.telegramButton}
              onPress={handleRequestTelegramAccess}
              activeOpacity={0.7}
            >
              <Text style={styles.telegramButtonText}>Request Telegram Access</Text>
            </TouchableOpacity>
            <Text style={styles.telegramCardFooter}>
              Support: @VerzekSupport
            </Text>
          </View>
        )}

        {/* Stats Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Trading Stats</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{stats?.active_positions || 0}</Text>
              <Text style={styles.statLabel}>Active Positions</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{stats?.total_trades || 0}</Text>
              <Text style={styles.statLabel}>Total Trades</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{stats?.winning_trades || 0}</Text>
              <Text style={styles.statLabel}>Wins</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{stats?.losing_trades || 0}</Text>
              <Text style={styles.statLabel}>Losses</Text>
            </View>
          </View>
        </View>

        {/* Recent Positions Monitor */}
        {recentPositions.length > 0 && (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Recent Positions</Text>
            {recentPositions.map((position, index) => (
              <View key={index} style={styles.positionItem}>
                <View style={styles.positionHeader}>
                  <Text style={styles.positionSymbol}>{position.symbol || 'N/A'}</Text>
                  <Text style={[
                    styles.positionStatus,
                    { color: getPositionStatusColor(position.status) }
                  ]}>
                    {getPositionStatusLabel(position.status)}
                  </Text>
                </View>
                <View style={styles.positionDetails}>
                  <Text style={styles.positionDetail}>
                    Entry: ${position.entry_price ? Number(position.entry_price).toFixed(2) : 'N/A'}
                  </Text>
                  {position.exit_price && (
                    <Text style={styles.positionDetail}>
                      Exit: ${Number(position.exit_price).toFixed(2)}
                    </Text>
                  )}
                  {(position.pnl !== null && position.pnl !== undefined) && (
                    <Text style={[
                      styles.positionPnL,
                      { color: position.pnl > 0 ? COLORS.tealBright : position.pnl < 0 ? COLORS.goldDark : COLORS.textSecondary }
                    ]}>
                      {position.pnl > 0 ? '+' : ''}{Number(position.pnl).toFixed(2)}%
                    </Text>
                  )}
                </View>
              </View>
            ))}
          </View>
        )}

        {/* Important Setup Notice */}
        <TouchableOpacity 
          style={styles.setupCard}
          onPress={() => setShowOnboarding(true)}
        >
          <Text style={styles.setupIcon}>⚠️</Text>
          <View style={styles.setupContent}>
            <Text style={styles.setupTitle}>Setup Instructions</Text>
            <Text style={styles.setupText}>
              Tap to view important trading setup instructions
            </Text>
          </View>
        </TouchableOpacity>

        {/* Feature Info */}
        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>🎯 Target-Based TP Active</Text>
          <Text style={styles.infoText}>
            Positions will automatically take profit at each target level
          </Text>
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>🛑 Auto-Stop Active</Text>
          <Text style={styles.infoText}>
            Positions auto-close on signal cancellation or stop loss hit
          </Text>
        </View>
      </ScrollView>

      <OnboardingModal 
        visible={showOnboarding} 
        onClose={handleCloseOnboarding}
      />
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bgDark,
  },
  content: {
    padding: 12,
    paddingBottom: 12,
  },
  logoContainer: {
    alignItems: 'center',
    marginVertical: 8,
  },
  logo: {
    width: 60,
    height: 60,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  greeting: {
    fontSize: 16,
    color: COLORS.textSecondary,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginTop: 4,
  },
  logoutButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: COLORS.bgCard,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  logoutText: {
    color: COLORS.goldDark,
    fontWeight: '600',
  },
  card: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 8,
  },
  cardSubtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  badge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  badgeText: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.bgDark,
  },
  expiryText: {
    fontSize: 12,
    color: COLORS.textMuted,
    marginTop: 8,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 8,
  },
  statItem: {
    width: '50%',
    marginBottom: 8,
  },
  statValue: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.gold,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  setupCard: {
    backgroundColor: COLORS.tealDark,
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: COLORS.gold,
  },
  setupIcon: {
    fontSize: 32,
    marginRight: 12,
  },
  setupContent: {
    flex: 1,
  },
  setupTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.gold,
    marginBottom: 4,
  },
  setupText: {
    fontSize: 14,
    color: COLORS.textPrimary,
  },
  infoCard: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
    borderLeftWidth: 4,
    borderLeftColor: COLORS.tealBright,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: COLORS.textSecondary,
  },
  statusBanner: {
    marginHorizontal: 12,
    marginBottom: 12,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 12,
  },
  statusInfo: {
    flex: 1,
  },
  statusTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 4,
  },
  statusSubtitle: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  upgradeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: COLORS.gold,
    borderRadius: 8,
    padding: 12,
    marginTop: 12,
  },
  upgradeButtonText: {
    fontSize: 15,
    fontWeight: '700',
    color: COLORS.bgDark,
  },
  upgradeArrow: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.bgDark,
  },
  positionItem: {
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
    paddingTop: 12,
    marginTop: 12,
  },
  positionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  positionSymbol: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.textPrimary,
  },
  telegramCard: {
    backgroundColor: `${COLORS.tealBright}15`,
    borderRadius: 12,
    padding: 16,
    marginBottom: 10,
    borderWidth: 2,
    borderColor: COLORS.tealBright,
  },
  telegramCardTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.textPrimary,
    marginBottom: 8,
  },
  telegramCardText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginBottom: 16,
    lineHeight: 20,
  },
  telegramButton: {
    backgroundColor: COLORS.tealBright,
    borderRadius: 8,
    padding: 14,
    alignItems: 'center',
    marginBottom: 8,
  },
  telegramButtonText: {
    fontSize: 15,
    fontWeight: '700',
    color: COLORS.bgDark,
  },
  telegramCardFooter: {
    fontSize: 12,
    color: COLORS.textMuted,
    textAlign: 'center',
    marginTop: 4,
  },
  positionStatus: {
    fontSize: 12,
    fontWeight: '700',
  },
  positionDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  positionDetail: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  positionPnL: {
    fontSize: 14,
    fontWeight: '700',
  },
});
