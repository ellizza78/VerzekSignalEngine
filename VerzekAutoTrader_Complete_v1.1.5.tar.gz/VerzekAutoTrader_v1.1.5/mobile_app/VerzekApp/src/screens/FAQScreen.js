import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Linking,
} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { COLORS } from '../constants/colors';

const FAQScreen = () => {
  const copyToClipboard = async (text, label) => {
    await Clipboard.setStringAsync(text);
    alert(`${label} copied to clipboard`);
  };

  const openEmail = () => {
    Linking.openURL('mailto:support@verzektrader.com');
  };

  const openTelegram = () => {
    Linking.openURL('https://t.me/VerzekSupport');
  };

  const Section = ({ emoji, title, children }) => (
    <View style={styles.section}>
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionEmoji}>{emoji}</Text>
        <Text style={styles.sectionTitle}>{title}</Text>
      </View>
      {children}
    </View>
  );

  const QA = ({ question, answer, isList = false, listItems = [] }) => (
    <View style={styles.qaContainer}>
      <Text style={styles.question}>Q: {question}</Text>
      {isList ? (
        <View style={styles.answerContainer}>
          <Text style={styles.answer}>A:</Text>
          {listItems.map((item, index) => (
            <Text key={index} style={styles.listItem}>
              {item}
            </Text>
          ))}
        </View>
      ) : (
        <Text style={styles.answer}>A: {answer}</Text>
      )}
    </View>
  );

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>📘 Verzek Auto Trader</Text>
        <Text style={styles.headerSubtitle}>Quick FAQ</Text>
      </View>

      {/* Support Contact */}
      <View style={styles.supportBox}>
        <TouchableOpacity style={styles.supportRow} onPress={openEmail}>
          <Text style={styles.supportIcon}>📧</Text>
          <View style={styles.supportInfo}>
            <Text style={styles.supportLabel}>Support:</Text>
            <Text style={styles.supportValue}>support@verzektrader.com</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity style={styles.supportRow} onPress={openTelegram}>
          <Text style={styles.supportIcon}>📱</Text>
          <View style={styles.supportInfo}>
            <Text style={styles.supportLabel}>Telegram:</Text>
            <Text style={styles.supportValue}>@VerzekSupport</Text>
          </View>
        </TouchableOpacity>
      </View>

      <View style={styles.divider} />

      {/* Section 1: Getting Started */}
      <Section emoji="1️⃣" title="Getting Started">
        <QA
          question="What is VerzekAutoTrader?"
          answer="It's an AI-driven auto-trading app that connects to Binance, Bybit, Phemex, and Kraken to trade automatically using verified Telegram signals and DCA strategy."
        />
        <QA
          question="How do I register?"
          answer="Download the app → Fill in details → Solve the sliding CAPTCHA → Verify your email. Done."
        />
      </Section>

      <View style={styles.divider} />

      {/* Section 2: Subscription & Payment */}
      <Section emoji="2️⃣" title="Subscription & Payment">
        <QA
          question="What plans are available?"
          isList={true}
          listItems={[
            '• TRIAL: Free for 4 days',
            '• VIP: $50/month',
            '• PREMIUM: $120/month',
          ]}
        />
        <View style={styles.qaContainer}>
          <Text style={styles.question}>Q: How do I pay?</Text>
          <Text style={styles.answer}>A: Send USDT (TRC20) to</Text>
          <TouchableOpacity
            style={styles.walletBox}
            onPress={() =>
              copyToClipboard(
                'TBjfqimYNsPecGxsk9kcX8GboPyZcWHNzb',
                'Wallet address'
              )
            }
          >
            <Text style={styles.walletAddress}>
              TBjfqimYNsPecGxsk9kcX8GboPyZcWHNzb
            </Text>
            <Text style={styles.walletCopy}>📋 Tap to Copy</Text>
          </TouchableOpacity>
          <Text style={styles.answer}>
            Then submit your TxID in the app for activation.
          </Text>
        </View>
      </Section>

      <View style={styles.divider} />

      {/* Section 3: Exchange Integration */}
      <Section emoji="3️⃣" title="Exchange Integration">
        <QA
          question="Which exchanges are supported?"
          answer="Binance Futures, Bybit, Phemex, and Kraken."
        />
        <QA
          question="Are my API keys safe?"
          answer="Yes. Keys are AES-128 encrypted and can't be used for withdrawals."
        />
        <View style={styles.qaContainer}>
          <Text style={styles.question}>Q: Do I need to whitelist an IP?</Text>
          <Text style={styles.answer}>
            A: Yes. For Binance, whitelist ALL these IPs for redundancy:
          </Text>
          <TouchableOpacity
            style={styles.ipBox}
            onPress={() => copyToClipboard('45.76.90.149\n209.222.24.189\n45.76.158.152\n207.148.80.196', 'IP addresses')}
          >
            <Text style={styles.ipAddress}>45.76.90.149 (Primary)</Text>
            <Text style={styles.ipAddress}>209.222.24.189</Text>
            <Text style={styles.ipAddress}>45.76.158.152</Text>
            <Text style={styles.ipAddress}>207.148.80.196</Text>
            <Text style={styles.ipCopy}>📋 Tap to Copy All</Text>
          </TouchableOpacity>
        </View>
      </Section>

      <View style={styles.divider} />

      {/* Section 4: Auto-Trading */}
      <Section emoji="4️⃣" title="Auto-Trading">
        <QA
          question="How does it work?"
          answer="The system listens to trading signals and executes trades automatically on your exchange — 24/7."
        />
        <QA
          question="Do I need to keep the app open?"
          answer="No. It runs on secure cloud servers even when you close the app."
        />
      </Section>

      <View style={styles.divider} />

      {/* Section 5: Security & Support */}
      <Section emoji="5️⃣" title="Security & Support">
        <QA
          question="Can Verzek withdraw my funds?"
          answer="No. Only trading and reading permissions are required for API keys."
        />
        <QA
          question="What's the sliding puzzle CAPTCHA for?"
          answer="It prevents bots during registration and login for better account security."
        />
        <View style={styles.qaContainer}>
          <Text style={styles.question}>Q: How can I reach support?</Text>
          <View style={styles.answerContainer}>
            <TouchableOpacity
              style={styles.contactButton}
              onPress={openEmail}
            >
              <Text style={styles.contactIcon}>📧</Text>
              <Text style={styles.contactText}>support@verzektrader.com</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.contactButton}
              onPress={openTelegram}
            >
              <Text style={styles.contactIcon}>📱</Text>
              <Text style={styles.contactText}>@VerzekSupport</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Section>

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Need more help? Contact our support team anytime!
        </Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bgDark,
  },
  content: {
    paddingBottom: 12,
  },
  header: {
    backgroundColor: COLORS.tealMid,
    padding: 14,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: COLORS.textPrimary,
    opacity: 0.9,
  },
  supportBox: {
    backgroundColor: COLORS.bgCard,
    marginHorizontal: 12,
    marginTop: 12,
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: COLORS.tealBright,
  },
  supportRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  supportIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  supportInfo: {
    flex: 1,
  },
  supportLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginBottom: 2,
  },
  supportValue: {
    fontSize: 14,
    color: COLORS.tealBright,
    fontWeight: '600',
  },
  divider: {
    height: 1,
    backgroundColor: COLORS.border,
    marginVertical: 12,
    marginHorizontal: 12,
  },
  section: {
    paddingHorizontal: 12,
    marginBottom: 8,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  sectionEmoji: {
    fontSize: 20,
    marginRight: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.gold,
  },
  qaContainer: {
    marginBottom: 12,
  },
  question: {
    fontSize: 15,
    fontWeight: '600',
    color: COLORS.tealBright,
    marginBottom: 8,
    lineHeight: 22,
  },
  answer: {
    fontSize: 14,
    color: COLORS.textPrimary,
    lineHeight: 20,
    marginBottom: 4,
  },
  answerContainer: {
    marginTop: 4,
  },
  listItem: {
    fontSize: 14,
    color: COLORS.textPrimary,
    lineHeight: 20,
    marginBottom: 4,
    paddingLeft: 8,
  },
  walletBox: {
    backgroundColor: COLORS.bgDark,
    padding: 12,
    borderRadius: 8,
    marginVertical: 8,
    borderWidth: 1,
    borderColor: COLORS.goldDark,
    alignItems: 'center',
  },
  walletAddress: {
    fontSize: 12,
    color: COLORS.goldDark,
    fontWeight: '600',
    marginBottom: 4,
    letterSpacing: 0.5,
  },
  walletCopy: {
    fontSize: 11,
    color: COLORS.textSecondary,
  },
  ipBox: {
    backgroundColor: COLORS.bgDark,
    padding: 12,
    borderRadius: 8,
    marginVertical: 8,
    borderWidth: 1,
    borderColor: COLORS.tealBright,
    alignItems: 'center',
  },
  ipAddress: {
    fontSize: 16,
    color: COLORS.tealBright,
    fontWeight: '600',
    marginBottom: 4,
    letterSpacing: 1,
  },
  ipCopy: {
    fontSize: 11,
    color: COLORS.textSecondary,
  },
  contactButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.bgCard,
    padding: 12,
    borderRadius: 8,
    marginTop: 8,
    borderWidth: 1,
    borderColor: COLORS.tealBright,
  },
  contactIcon: {
    fontSize: 18,
    marginRight: 10,
  },
  contactText: {
    fontSize: 14,
    color: COLORS.tealBright,
    fontWeight: '500',
  },
  footer: {
    backgroundColor: COLORS.bgCard,
    marginHorizontal: 16,
    marginTop: 24,
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    textAlign: 'center',
    fontStyle: 'italic',
  },
});

export default FAQScreen;
