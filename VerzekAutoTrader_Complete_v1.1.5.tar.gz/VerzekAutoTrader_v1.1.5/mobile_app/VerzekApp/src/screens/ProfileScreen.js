import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
} from 'react-native';
import * as Clipboard from 'expo-clipboard';
import { COLORS } from '../constants/colors';
import { useAuth } from '../context/AuthContext';

const ProfileScreen = ({ navigation }) => {
  const { user } = useAuth();

  const copyToClipboard = async (text, label) => {
    await Clipboard.setStringAsync(text);
    Alert.alert('Copied!', `${label} copied to clipboard`);
  };

  const getPlanBadge = (plan) => {
    const badges = {
      free: { text: 'FREE Member', color: COLORS.textMuted },
      pro: { text: 'PRO Member', color: COLORS.goldDark },
      vip: { text: 'VIP Member', color: '#9333EA' },
    };
    return badges[plan] || badges.free;
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: '2-digit', 
      day: '2-digit' 
    });
  };

  const planBadge = getPlanBadge(user?.plan);
  const isExpired = user?.is_subscription_expired;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {/* Profile Header */}
      <View style={styles.header}>
        <View style={styles.avatarContainer}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {user?.full_name?.charAt(0)?.toUpperCase() || 'U'}
            </Text>
          </View>
        </View>
        
        <View style={styles.headerInfo}>
          <View style={styles.nameRow}>
            <Text style={styles.username}>{user?.full_name || 'User'}</Text>
            <View style={[styles.badge, { backgroundColor: `${planBadge.color}20` }]}>
              <Text style={[styles.badgeText, { color: planBadge.color }]}>
                {planBadge.text}
              </Text>
            </View>
          </View>
          
          <TouchableOpacity 
            style={styles.emailRow}
            onPress={() => copyToClipboard(user?.email, 'Email')}
          >
            <Text style={styles.email}>ID: {user?.email}</Text>
            <Text style={styles.copyIcon}>📋</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Subscription Card */}
      {user?.plan !== 'free' && (
        <View style={styles.subscriptionCard}>
          <View style={styles.subscriptionLeft}>
            <TouchableOpacity 
              style={styles.permissionButton}
              onPress={() => navigation.navigate('UserGuide')}
            >
              <Text style={styles.permissionText}>View Features</Text>
              <Text style={styles.permissionArrow}>›</Text>
            </TouchableOpacity>
            
            <View style={styles.billingInfo}>
              <Text style={styles.billingLabel}>
                {isExpired ? 'Expired on:' : 'Next billing date:'}
              </Text>
              <Text style={styles.billingDate}>
                {formatDate(user?.plan_expires_at)}
              </Text>
            </View>
            
            <TouchableOpacity 
              style={styles.renewalButton}
              onPress={() => navigation.navigate('Subscription')}
            >
              <Text style={styles.renewalText}>
                {isExpired ? 'Renew Subscription' : 'Manage Subscription'}
              </Text>
              <Text style={styles.renewalArrow}>›</Text>
            </TouchableOpacity>
          </View>
          
          {!isExpired && (
            <TouchableOpacity style={styles.cancelButton}>
              <Text style={styles.cancelText}>Active</Text>
            </TouchableOpacity>
          )}
        </View>
      )}

      {/* Referral Code Section */}
      <View style={styles.referralCard}>
        <Text style={styles.referralTitle}>Your Referral Code</Text>
        <TouchableOpacity 
          style={styles.referralCodeBox}
          onPress={() => copyToClipboard(user?.referral_code || user?.user_id, 'Referral code')}
        >
          <Text style={styles.referralCode}>{user?.referral_code || user?.user_id?.substring(0, 8).toUpperCase()}</Text>
          <Text style={styles.referralCopy}>📋 Tap to Copy</Text>
        </TouchableOpacity>
        <Text style={styles.referralHint}>Share with friends and earn 10% monthly commissions!</Text>
      </View>

      {/* Menu Items */}
      <View style={styles.menuSection}>
        <TouchableOpacity 
          style={styles.menuItem}
          onPress={() => navigation.navigate('Rewards')}
        >
          <Text style={styles.menuIcon}>🎁</Text>
          <Text style={styles.menuText}>Reward Details</Text>
          <Text style={styles.menuArrow}>›</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.menuItem}
          onPress={() => navigation.navigate('Exchanges')}
        >
          <Text style={styles.menuIcon}>🔗</Text>
          <Text style={styles.menuText}>API Binding</Text>
          <Text style={styles.menuArrow}>›</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.menuItem}
          onPress={() => navigation.navigate('Positions')}
        >
          <Text style={styles.menuIcon}>📊</Text>
          <Text style={styles.menuText}>My Active Positions</Text>
          <Text style={styles.menuArrow}>›</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.menuItem}
          onPress={() => navigation.navigate('Settings')}
        >
          <Text style={styles.menuIcon}>⚙️</Text>
          <Text style={styles.menuText}>Trading Settings</Text>
          <Text style={styles.menuArrow}>›</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.menuItem}
          onPress={() => navigation.navigate('UserGuide')}
        >
          <Text style={styles.menuIcon}>📖</Text>
          <Text style={styles.menuText}>User Guide</Text>
          <Text style={styles.menuArrow}>›</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.menuItem}
          onPress={() => navigation.navigate('FAQ')}
        >
          <Text style={styles.menuIcon}>❓</Text>
          <Text style={styles.menuText}>FAQ</Text>
          <Text style={styles.menuArrow}>›</Text>
        </TouchableOpacity>
      </View>

      {/* Support Section */}
      <View style={styles.supportSection}>
        <Text style={styles.supportTitle}>Need Help?</Text>
        <TouchableOpacity 
          style={styles.supportMainButton}
          onPress={() => navigation.navigate('Support')}
        >
          <Text style={styles.supportMainIcon}>🆘</Text>
          <View style={styles.supportMainInfo}>
            <Text style={styles.supportMainText}>Contact Support</Text>
            <Text style={styles.supportMainSubtext}>Send us a message directly</Text>
          </View>
          <Text style={styles.supportMainArrow}>›</Text>
        </TouchableOpacity>
      </View>

      {/* Profile Details */}
      <View style={styles.detailsSection}>
        <Text style={styles.sectionTitle}>Account Details</Text>
        
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>User ID</Text>
          <TouchableOpacity 
            style={styles.detailValueRow}
            onPress={() => copyToClipboard(user?.user_id, 'User ID')}
          >
            <Text style={styles.detailValue} numberOfLines={1}>
              {user?.user_id?.substring(0, 20)}...
            </Text>
            <Text style={styles.detailCopy}>📋</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Email</Text>
          <View style={styles.detailValueRow}>
            <Text style={styles.detailValue}>{user?.email}</Text>
            <View style={styles.verifiedBadge}>
              <Text style={styles.verifiedText}>
                {user?.email_verified ? '✓ Verified' : 'Not Verified'}
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Full Name</Text>
          <Text style={styles.detailValue}>{user?.full_name || 'N/A'}</Text>
        </View>

        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Plan Status</Text>
          <Text style={[styles.detailValue, { color: planBadge.color }]}>
            {user?.plan?.toUpperCase()}
          </Text>
        </View>

        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>2FA Status</Text>
          <Text style={styles.detailValue}>
            {user?.mfa_enabled ? 'Enabled' : 'Disabled'}
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.bgDark,
  },
  content: {
    paddingBottom: 12,
  },
  header: {
    backgroundColor: COLORS.tealMid,
    paddingTop: 10,
    paddingBottom: 12,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatarContainer: {
    marginRight: 12,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: COLORS.goldDark,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: COLORS.textPrimary,
  },
  avatarText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
  },
  headerInfo: {
    flex: 1,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  username: {
    fontSize: 22,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginRight: 8,
  },
  badge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  badgeText: {
    fontSize: 11,
    fontWeight: '600',
  },
  emailRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  email: {
    fontSize: 14,
    color: COLORS.textPrimary,
    marginRight: 6,
  },
  copyIcon: {
    fontSize: 12,
  },
  subscriptionCard: {
    backgroundColor: COLORS.goldDark,
    margin: 12,
    marginTop: 12,
    padding: 14,
    borderRadius: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  subscriptionLeft: {
    flex: 1,
  },
  permissionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  permissionText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.bgDark,
    marginRight: 4,
  },
  permissionArrow: {
    fontSize: 20,
    color: COLORS.bgDark,
  },
  billingInfo: {
    marginBottom: 12,
  },
  billingLabel: {
    fontSize: 13,
    color: COLORS.bgDark,
    opacity: 0.8,
  },
  billingDate: {
    fontSize: 15,
    fontWeight: '600',
    color: COLORS.bgDark,
    marginTop: 2,
  },
  renewalButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  renewalText: {
    fontSize: 15,
    fontWeight: '500',
    color: COLORS.bgDark,
    marginRight: 4,
  },
  renewalArrow: {
    fontSize: 18,
    color: COLORS.bgDark,
  },
  cancelButton: {
    backgroundColor: COLORS.textPrimary,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  cancelText: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.goldDark,
  },
  menuSection: {
    marginTop: 8,
  },
  menuItem: {
    backgroundColor: COLORS.bgCard,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    paddingVertical: 12,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  menuIcon: {
    fontSize: 22,
    marginRight: 16,
  },
  menuText: {
    flex: 1,
    fontSize: 16,
    color: COLORS.textPrimary,
  },
  menuArrow: {
    fontSize: 20,
    color: COLORS.textMuted,
  },
  detailsSection: {
    marginTop: 16,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  detailLabel: {
    fontSize: 15,
    color: COLORS.textSecondary,
  },
  detailValueRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  detailValue: {
    fontSize: 15,
    color: COLORS.textPrimary,
    fontWeight: '500',
  },
  detailCopy: {
    fontSize: 14,
    marginLeft: 8,
  },
  verifiedBadge: {
    backgroundColor: `${COLORS.tealBright}20`,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    marginLeft: 8,
  },
  verifiedText: {
    fontSize: 12,
    color: COLORS.tealBright,
    fontWeight: '600',
  },
  referralCard: {
    backgroundColor: `${COLORS.tealBright}15`,
    borderWidth: 2,
    borderColor: COLORS.tealBright,
    borderRadius: 12,
    padding: 14,
    marginHorizontal: 12,
    marginTop: 12,
    marginBottom: 8,
  },
  referralTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.tealBright,
    marginBottom: 12,
    textAlign: 'center',
  },
  referralCodeBox: {
    backgroundColor: COLORS.bgDark,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 8,
  },
  referralCode: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.goldDark,
    letterSpacing: 2,
    marginBottom: 4,
  },
  referralCopy: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  referralHint: {
    fontSize: 13,
    color: COLORS.textPrimary,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  supportSection: {
    marginHorizontal: 12,
    marginTop: 16,
    marginBottom: 16,
  },
  supportTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 10,
  },
  supportMainButton: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: COLORS.goldDark,
  },
  supportMainIcon: {
    fontSize: 28,
    marginRight: 12,
  },
  supportMainInfo: {
    flex: 1,
  },
  supportMainText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    marginBottom: 2,
  },
  supportMainSubtext: {
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  supportMainArrow: {
    fontSize: 24,
    color: COLORS.goldDark,
  },
});

export default ProfileScreen;
