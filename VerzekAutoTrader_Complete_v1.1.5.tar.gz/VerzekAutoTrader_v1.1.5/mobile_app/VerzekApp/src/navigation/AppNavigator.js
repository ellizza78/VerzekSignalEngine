import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useAuth } from '../context/AuthContext';
import { ActivityIndicator, View, Text } from 'react-native';
import { useInactivityLogout } from '../hooks/useInactivityLogout';

// Auth Screens
import LoginScreen from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import ForgotPasswordScreen from '../screens/ForgotPasswordScreen';
import EmailVerificationScreen from '../screens/EmailVerificationScreen';

// Main Screens
import DashboardScreen from '../screens/DashboardScreen';
import SignalsFeedScreen from '../screens/SignalsFeedScreen';
import PositionsScreen from '../screens/PositionsScreen';
import ExchangeAccountsScreen from '../screens/ExchangeAccountsScreen';
import ExchangeDetailScreen from '../screens/ExchangeDetailScreen';
import RewardsScreen from '../screens/RewardsScreen';
import UserGuideScreen from '../screens/UserGuideScreen';
import GuideDetailScreen from '../screens/GuideDetailScreen';
import ProfileScreen from '../screens/ProfileScreen';
import SubscriptionScreen from '../screens/SubscriptionScreen';
import SettingsScreen from '../screens/SettingsScreen';
import FAQScreen from '../screens/FAQScreen';
import SupportScreen from '../screens/SupportScreen';
import HelpResourcesScreen from '../screens/HelpResourcesScreen';
import ReferralsScreen from '../screens/ReferralsScreen';
import { COLORS } from '../constants/colors';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// Tab Navigator for Main App
function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: COLORS.bgDark,
        },
        headerTintColor: COLORS.textPrimary,
        headerTitleStyle: {
          fontWeight: 'bold',
        },
        tabBarStyle: {
          backgroundColor: COLORS.bgMid,
          borderTopWidth: 1,
          borderTopColor: COLORS.border,
          paddingTop: 8,
          paddingBottom: 8,
          height: 60,
        },
        tabBarActiveTintColor: COLORS.gold,
        tabBarInactiveTintColor: COLORS.textMuted,
        tabBarLabelStyle: {
          fontSize: 12,
          fontWeight: '600',
        },
      }}
    >
      <Tab.Screen
        name="Dashboard"
        component={DashboardScreen}
        options={{
          title: 'Dashboard',
          tabBarIcon: ({ color }) => (
            <Text style={{ fontSize: 24 }}>🏠</Text>
          ),
        }}
      />
      <Tab.Screen
        name="Signals"
        component={SignalsFeedScreen}
        options={{
          title: 'Signals Feed',
          tabBarIcon: ({ color }) => (
            <Text style={{ fontSize: 24 }}>📡</Text>
          ),
        }}
      />
      <Tab.Screen
        name="Positions"
        component={PositionsScreen}
        options={{
          title: 'Positions',
          tabBarIcon: ({ color }) => (
            <Text style={{ fontSize: 24 }}>📊</Text>
          ),
        }}
      />
      <Tab.Screen
        name="Exchanges"
        component={ExchangeAccountsScreen}
        options={{
          title: 'Exchange Setup',
          tabBarIcon: ({ color }) => (
            <Text style={{ fontSize: 24 }}>🔗</Text>
          ),
        }}
      />
      <Tab.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          title: 'Profile',
          tabBarIcon: ({ color }) => (
            <Text style={{ fontSize: 24 }}>👤</Text>
          ),
        }}
      />
      <Tab.Screen
        name="Settings"
        component={SettingsScreen}
        options={{
          title: 'Settings',
          tabBarIcon: ({ color }) => (
            <Text style={{ fontSize: 24 }}>⚙️</Text>
          ),
        }}
      />
    </Tab.Navigator>
  );
}

// Main Stack with Tabs and Detail Screens
function MainStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: {
          backgroundColor: COLORS.bgDark,
        },
        headerTintColor: COLORS.textPrimary,
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
    >
      <Stack.Screen 
        name="MainTabs" 
        component={MainTabs} 
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="ExchangeDetail" 
        component={ExchangeDetailScreen}
        options={{ title: 'Exchange Setup' }}
      />
      <Stack.Screen 
        name="Rewards" 
        component={RewardsScreen}
        options={{ title: 'Referral Rewards' }}
      />
      <Stack.Screen 
        name="Referrals" 
        component={ReferralsScreen}
        options={{ title: 'My Referrals' }}
      />
      <Stack.Screen 
        name="UserGuide" 
        component={UserGuideScreen}
        options={{ title: 'User Guide' }}
      />
      <Stack.Screen 
        name="GuideDetail" 
        component={GuideDetailScreen}
        options={{ title: 'Guide' }}
      />
      <Stack.Screen 
        name="Subscription" 
        component={SubscriptionScreen}
        options={{ title: 'Subscribe' }}
      />
      <Stack.Screen 
        name="FAQ" 
        component={FAQScreen}
        options={{ title: 'FAQ' }}
      />
      <Stack.Screen 
        name="Support" 
        component={SupportScreen}
        options={{ title: 'Support' }}
      />
      <Stack.Screen 
        name="HelpResources" 
        component={HelpResourcesScreen}
        options={{ title: 'Help & Resources' }}
      />
    </Stack.Navigator>
  );
}

export default function AppNavigator() {
  const { isAuthenticated, loading, logout, user } = useAuth();
  const panResponder = useInactivityLogout(isAuthenticated, logout);

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: COLORS.bgDark }}>
        <ActivityIndicator size="large" color={COLORS.gold} />
      </View>
    );
  }

  // SECURITY: Check if user exists but email is not verified
  const needsEmailVerification = user && !user.email_verified && !isAuthenticated;

  return (
    <View style={{ flex: 1 }} {...panResponder.panHandlers}>
      <NavigationContainer>
        {isAuthenticated ? (
          // Authenticated Stack with Bottom Tabs + Detail Screens
          <MainStack />
        ) : needsEmailVerification ? (
          // Email Verification Required - show verification screen first
          <Stack.Navigator
            screenOptions={{
              headerShown: false,
            }}
            initialRouteName="EmailVerification"
          >
            <Stack.Screen name="EmailVerification" component={EmailVerificationScreen} />
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="Register" component={RegisterScreen} />
            <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
          </Stack.Navigator>
        ) : (
          // Auth Stack - normal login flow
          <Stack.Navigator
            screenOptions={{
              headerShown: false,
            }}
          >
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="Register" component={RegisterScreen} />
            <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
            <Stack.Screen name="EmailVerification" component={EmailVerificationScreen} />
          </Stack.Navigator>
        )}
      </NavigationContainer>
    </View>
  );
}
