import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_BASE_URL } from '../config/api';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
    'User-Agent': 'VerzekAutoTrader/1.0 (Expo; React-Native)',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  async (config) => {
    const token = await AsyncStorage.getItem('access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for token refresh
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    // If 401 and not already retried, try to refresh token
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        const refreshToken = await AsyncStorage.getItem('refresh_token');
        if (refreshToken) {
          const response = await axios.post(`${API_BASE_URL}/api/auth/refresh`, {}, {
            headers: { Authorization: `Bearer ${refreshToken}` },
          });

          const { access_token } = response.data;
          await AsyncStorage.setItem('access_token', access_token);

          // Retry original request with new token
          originalRequest.headers.Authorization = `Bearer ${access_token}`;
          return api(originalRequest);
        }
      } catch (refreshError) {
        // Refresh failed, logout user
        await AsyncStorage.multiRemove(['access_token', 'refresh_token', 'user']);
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  register: (email, password, fullName, captchaHash, captchaText, referralCode = null) =>
    api.post('/api/auth/register', { 
      email, 
      password, 
      full_name: fullName,
      captcha_hash: captchaHash,
      captcha_text: captchaText,
      referral_code: referralCode
    }),

  login: (email, password, captchaHash, captchaText) =>
    api.post('/api/auth/login', { 
      email, 
      password,
      captcha_hash: captchaHash,
      captcha_text: captchaText
    }),

  refreshToken: () =>
    api.post('/api/auth/refresh'),

  getCurrentUser: () =>
    api.get('/api/auth/me'),

  checkVerification: () =>
    api.get('/api/auth/check-verification'),

  resendVerification: () =>
    api.post('/api/auth/resend-verification'),

  forgotPassword: (email) =>
    api.post('/api/auth/forgot-password', { email }),
};

// User API
export const userAPI = {
  getUser: (userId) =>
    api.get(`/api/users/${userId}`),

  updateGeneral: (userId, settings) =>
    api.put(`/api/users/${userId}/general`, settings),

  updateRisk: (userId, settings) =>
    api.put(`/api/users/${userId}/risk`, settings),

  updateStrategy: (userId, settings) =>
    api.put(`/api/users/${userId}/strategy`, settings),

  updatePreferences: (userId, settings) =>
    api.put(`/api/users/${userId}/preferences`, settings),

  updateDCA: (userId, settings) =>
    api.put(`/api/users/${userId}/dca`, settings),

  getSubscription: (userId) =>
    api.get(`/api/users/${userId}/subscription`),

  activateSubscription: (userId, plan, durationDays) =>
    api.post(`/api/users/${userId}/subscription`, { plan, duration_days: durationDays }),

  addExchangeAccount: (userId, accountData) =>
    api.post(`/api/users/${userId}/exchanges`, accountData),

  removeExchangeAccount: (userId, accountId) =>
    api.delete(`/api/users/${userId}/exchanges`, { data: { account_id: accountId } }),

  getReferralRewards: (userId) =>
    api.get(`/api/referral/stats`),

  getReferralCode: () =>
    api.get(`/api/referral/code`),

  getWalletBalance: () =>
    api.get(`/api/wallet/balance`),

  requestPayout: (userId, payoutData) =>
    api.post(`/api/referral/payout`, payoutData),

  getExchangeBalance: (userId, exchange) =>
    api.get(`/api/users/${userId}/balance/${exchange}`),

  getExchangeLeverage: (userId, exchange) =>
    api.get(`/api/users/${userId}/exchanges/${exchange}/leverage`),

  updateExchangeLeverage: (userId, exchange, leverage) =>
    api.put(`/api/users/${userId}/exchanges/${exchange}/leverage`, { leverage }),

  requestTelegramAccess: () =>
    api.post('/api/users/request-telegram-access'),
};

// Positions API
export const positionsAPI = {
  getAllPositions: () =>
    api.get('/api/positions'),

  getUserPositions: (userId) =>
    api.get(`/api/positions/${userId}`),
};

// Signals API
export const signalsAPI = {
  getSignals: () =>
    api.get('/api/signals'),
};

// System API
export const systemAPI = {
  getServerIP: () =>
    api.get('/api/system/ip'),
};

// CAPTCHA API
export const captchaAPI = {
  generateCaptcha: () =>
    api.get('/api/captcha/generate'),
  
  verifyCaptcha: (captchaHash, captchaText) =>
    api.post('/api/captcha/verify', { captcha_hash: captchaHash, captcha_text: captchaText }),
};

// Referral API
export const referralAPI = {
  getReferrals: (userId) =>
    api.get(`/api/referrals/${userId}`),
};

// Payment API
export const paymentAPI = {
  // Step 1: Create payment request (get payment_id and admin wallet)
  createPayment: (plan) =>
    api.post('/api/payments/create', { plan }),

  // Step 2: Submit payment verification with tx_hash
  verifyPayment: (paymentId, txHash, referralCode) =>
    api.post('/api/payments/verify', {
      payment_id: paymentId,
      tx_hash: txHash,
      referral_code: referralCode || null,
    }),

  // Legacy function for backward compatibility (calls create then verify)
  submitPayment: async (plan, amount, txHash, referralCode) => {
    try {
      const createResult = await api.post('/api/payments/create', { plan });
      if (!createResult.payment_id) {
        throw new Error('Failed to create payment');
      }
      return await api.post('/api/payments/verify', {
        payment_id: createResult.payment_id,
        tx_hash: txHash,
        referral_code: referralCode || null,
      });
    } catch (error) {
      throw error;
    }
  },

  getPaymentStatus: (paymentId) =>
    api.get(`/api/payments/${paymentId}`),
  
  getMyPayments: () =>
    api.get('/api/payments/my-payments'),
};

export default api;
