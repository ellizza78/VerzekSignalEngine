import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  PanResponder,
  Animated,
  Dimensions,
} from 'react-native';
import { COLORS } from '../constants/colors';

const SCREEN_WIDTH = Dimensions.get('window').width;
const SLIDER_WIDTH = SCREEN_WIDTH - 80;
const THUMB_SIZE = 50;
const COMPLETION_THRESHOLD = 0.9;

export default function SliderCaptcha({ onVerified }) {
  const [verified, setVerified] = useState(false);
  const position = useRef(new Animated.Value(0)).current;
  const [currentPosition, setCurrentPosition] = useState(0);

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => !verified,
      onMoveShouldSetPanResponder: () => !verified,
      onPanResponderGrant: () => {
        position.setOffset(currentPosition);
        position.setValue(0);
      },
      onPanResponderMove: (_, gesture) => {
        if (gesture.dx >= 0 && gesture.dx <= SLIDER_WIDTH - THUMB_SIZE) {
          position.setValue(gesture.dx);
        }
      },
      onPanResponderRelease: (_, gesture) => {
        position.flattenOffset();
        const finalPosition = currentPosition + gesture.dx;
        
        if (finalPosition >= (SLIDER_WIDTH - THUMB_SIZE) * COMPLETION_THRESHOLD) {
          Animated.spring(position, {
            toValue: SLIDER_WIDTH - THUMB_SIZE,
            useNativeDriver: false,
            tension: 50,
            friction: 7,
          }).start(() => {
            setVerified(true);
            setCurrentPosition(SLIDER_WIDTH - THUMB_SIZE);
            if (onVerified) {
              onVerified();
            }
          });
        } else {
          Animated.spring(position, {
            toValue: 0,
            useNativeDriver: false,
            tension: 50,
            friction: 7,
          }).start(() => {
            setCurrentPosition(0);
          });
        }
      },
    })
  ).current;

  return (
    <View style={styles.container}>
      {/* Logo Display */}
      <View style={styles.logoContainer}>
        <Image
          source={require('../../assets/vzk-logo.png')}
          style={styles.logo}
          resizeMode="contain"
        />
      </View>

      {/* Instruction Text */}
      <Text style={[styles.instructionText, verified && styles.verifiedText]}>
        {verified ? '✓ Verified!' : 'Drag the slider to verify'}
      </Text>

      {/* Slider Track */}
      <View style={styles.sliderTrack}>
        {/* Progress Fill */}
        <Animated.View
          style={[
            styles.progressFill,
            {
              width: position.interpolate({
                inputRange: [0, SLIDER_WIDTH - THUMB_SIZE],
                outputRange: [0, SLIDER_WIDTH],
                extrapolate: 'clamp',
              }),
            },
            verified && styles.progressFillVerified,
          ]}
        />

        {/* Slider Thumb */}
        <Animated.View
          style={[
            styles.sliderThumb,
            {
              transform: [
                {
                  translateX: position.interpolate({
                    inputRange: [0, SLIDER_WIDTH - THUMB_SIZE],
                    outputRange: [0, SLIDER_WIDTH - THUMB_SIZE],
                    extrapolate: 'clamp',
                  }),
                },
              ],
            },
            verified && styles.sliderThumbVerified,
          ]}
          {...panResponder.panHandlers}
        >
          <Text style={styles.arrowIcon}>{verified ? '✓' : '›'}</Text>
        </Animated.View>
      </View>

      {verified && (
        <Text style={styles.successMessage}>Security verification complete</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginVertical: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  logoContainer: {
    width: SLIDER_WIDTH,
    height: 180,
    backgroundColor: COLORS.tealDark,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 2,
    borderColor: COLORS.tealBright,
  },
  logo: {
    width: 120,
    height: 120,
  },
  instructionText: {
    fontSize: 16,
    color: COLORS.textSecondary,
    marginBottom: 16,
    fontWeight: '500',
  },
  verifiedText: {
    color: '#10B981',
    fontWeight: '600',
  },
  sliderTrack: {
    width: SLIDER_WIDTH,
    height: 50,
    backgroundColor: '#E5E7EB',
    borderRadius: 25,
    position: 'relative',
    overflow: 'hidden',
  },
  progressFill: {
    position: 'absolute',
    left: 0,
    top: 0,
    height: '100%',
    backgroundColor: COLORS.tealBright,
    borderRadius: 25,
    opacity: 0.3,
  },
  progressFillVerified: {
    backgroundColor: '#10B981',
    opacity: 0.5,
  },
  sliderThumb: {
    position: 'absolute',
    left: 0,
    top: 0,
    width: THUMB_SIZE,
    height: THUMB_SIZE,
    backgroundColor: COLORS.tealBright,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  sliderThumbVerified: {
    backgroundColor: '#10B981',
  },
  arrowIcon: {
    fontSize: 24,
    color: 'white',
    fontWeight: 'bold',
  },
  successMessage: {
    fontSize: 13,
    color: '#10B981',
    marginTop: 12,
    fontWeight: '500',
  },
});
