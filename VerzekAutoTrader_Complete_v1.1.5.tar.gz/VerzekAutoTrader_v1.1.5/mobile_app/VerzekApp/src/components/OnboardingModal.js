import React from 'react';
import {
  Modal,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
} from 'react-native';
import { COLORS } from '../constants/colors';

export default function OnboardingModal({ visible, onClose }) {
  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.modalContainer}>
          <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
            <View style={styles.header}>
              <Text style={styles.title}>⚠️ Important Setup Instructions</Text>
              <Text style={styles.subtitle}>Please read carefully before trading</Text>
            </View>

            <View style={styles.instructionCard}>
              <View style={styles.stepHeader}>
                <View style={styles.stepNumber}>
                  <Text style={styles.stepNumberText}>1</Text>
                </View>
                <Text style={styles.stepTitle}>Exchange Configuration</Text>
              </View>
              <Text style={styles.instructionText}>
                <Text style={styles.bold}>SET ALL TRADING COINS ON YOUR EXCHANGES (FUTURES) TO ISOLATED MARGIN</Text>
              </Text>
              <View style={styles.warningBox}>
                <Text style={styles.warningText}>
                  ⚡ This is CRITICAL for risk management. Isolated margin ensures losses are limited to individual positions.
                </Text>
              </View>
            </View>

            <View style={styles.instructionCard}>
              <View style={styles.stepHeader}>
                <View style={styles.stepNumber}>
                  <Text style={styles.stepNumberText}>2</Text>
                </View>
                <Text style={styles.stepTitle}>Configure Auto Trade Settings</Text>
              </View>
              <Text style={styles.instructionText}>
                <Text style={styles.bold}>CAREFULLY SET UP AUTO TRADES SETTINGS IN THE APP</Text>
              </Text>
              <View style={styles.tipsList}>
                <Text style={styles.tipText}>• Navigate to Settings tab</Text>
                <Text style={styles.tipText}>• Configure risk parameters (capital, leverage limits)</Text>
                <Text style={styles.tipText}>• Set DCA levels and multipliers</Text>
                <Text style={styles.tipText}>• Enable auto-follow only when ready</Text>
                <Text style={styles.tipText}>• Test with small amounts first</Text>
              </View>
            </View>

            <View style={styles.instructionCard}>
              <View style={styles.stepHeader}>
                <View style={styles.stepNumber}>
                  <Text style={styles.stepNumberText}>3</Text>
                </View>
                <Text style={styles.stepTitle}>Whitelist Server IP & Connect Exchange</Text>
              </View>
              <Text style={styles.instructionText}>
                <Text style={styles.bold}>IMPORTANT:</Text> Exchanges like Binance require IP whitelisting before creating API keys.
              </Text>
              <View style={styles.tipsList}>
                <Text style={styles.tipText}>• Go to "Exchange Setup" tab to copy server IP</Text>
                <Text style={styles.tipText}>• On your exchange, whitelist this IP when creating API keys</Text>
                <Text style={styles.tipText}>• Enable "Enable Futures" + "Enable Reading" permissions</Text>
                <Text style={styles.tipText}>• Select "Restrict access to trusted IPs only" (recommended)</Text>
                <Text style={styles.tipText}>• Never share your API keys with anyone</Text>
              </View>
              <View style={styles.warningBox}>
                <Text style={styles.warningText}>
                  🔐 Without IP whitelisting, you cannot create API keys for Futures trading on most exchanges.
                </Text>
              </View>
            </View>

            <TouchableOpacity style={styles.button} onPress={onClose}>
              <Text style={styles.buttonText}>I Understand - Continue</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: COLORS.overlay,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContainer: {
    backgroundColor: COLORS.bgCard,
    borderRadius: 20,
    width: '100%',
    maxHeight: '90%',
    borderWidth: 2,
    borderColor: COLORS.tealBright,
  },
  content: {
    padding: 24,
  },
  header: {
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.gold,
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    textAlign: 'center',
  },
  instructionCard: {
    backgroundColor: COLORS.bgDark,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderLeftWidth: 4,
    borderLeftColor: COLORS.tealBright,
  },
  stepHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  stepNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: COLORS.tealBright,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  stepNumberText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.bgDark,
  },
  stepTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
    flex: 1,
  },
  instructionText: {
    fontSize: 15,
    color: COLORS.textSecondary,
    lineHeight: 22,
    marginBottom: 12,
  },
  bold: {
    fontWeight: 'bold',
    color: COLORS.gold,
  },
  warningBox: {
    backgroundColor: `${COLORS.gold}1A`,
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: COLORS.gold,
  },
  warningText: {
    fontSize: 13,
    color: COLORS.gold,
    lineHeight: 20,
  },
  tipsList: {
    marginTop: 8,
  },
  tipText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    lineHeight: 24,
    marginLeft: 8,
  },
  button: {
    backgroundColor: COLORS.tealBright,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 10,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.textPrimary,
  },
});
