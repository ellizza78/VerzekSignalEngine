export const EXCHANGE_CONFIG = {
  binance: {
    name: 'Binance',
    logo: '📊',
    precautions: [
      'Please ensure that "Enable Spot & Margin Trading" is checked in the API permissions.',
      'Please enter the correct API key and avoid using special characters.',
      'To use Futures strategy, please check the "Enable Futures" in API management.',
    ],
    ipBinding: {
      title: 'IP Group Binding',
      description: 'For security purposes, Binance exchange suggest users to bind IP addresses when creating API. Please click copy to copy the IP address and paste it to the IP address on the Binance IP binding page. Please click confirm to complete the binding.',
    },
    requirements: [
      'Enable Futures trading permission',
      'Enable Spot & Margin trading (optional)',
      'Whitelist IP address in API settings',
      'Use ISOLATED margin mode (NOT Cross Margin)',
    ],
  },
  bybit: {
    name: 'Bybit',
    logo: '🔷',
    precautions: [
      'Please ensure "Contract Trade" permission is enabled for your API key.',
      'API key must have read and write permissions for trading.',
      'For security, enable IP whitelisting and add our server IP.',
    ],
    ipBinding: {
      title: 'IP Whitelisting',
      description: 'Bybit requires IP whitelisting for API access. Copy the IP address below and add it to your API key settings in Bybit.',
    },
    requirements: [
      'Enable Contract Trade permission',
      'Enable Read/Write permissions',
      'Add server IP to whitelist',
      'Use Isolated margin for futures',
    ],
  },
  phemex: {
    name: 'Phemex',
    logo: '⚡',
    precautions: [
      'Ensure your API key has "Trade" permission enabled.',
      'API secret must be kept secure and never shared.',
      'Enable IP restriction for enhanced security.',
    ],
    ipBinding: {
      title: 'IP Restriction',
      description: 'For enhanced security, Phemex recommends restricting API access to specific IP addresses. Copy and paste our server IP in your Phemex API settings.',
    },
    requirements: [
      'Enable Trade permission',
      'Enable Futures trading access',
      'Add server IP to restricted IPs',
      'Keep API secret secure',
    ],
  },
  kraken: {
    name: 'Kraken Futures',
    logo: '🐙',
    precautions: [
      'API key must have futures trading permissions.',
      'Ensure "Access Futures" is enabled in API settings.',
      'Use unique API keys for each trading bot.',
    ],
    ipBinding: {
      title: 'IP Whitelisting',
      description: 'Kraken supports IP whitelisting for API keys. Add our server IP address to your API key configuration for enhanced security.',
    },
    requirements: [
      'Enable Access Futures permission',
      'Enable Trade permission',
      'Add server IP to whitelist (optional)',
      'Use separate API keys per bot',
    ],
  },
};
