export const COLORS = {
  // Primary Brand Colors (matching VZK logo)
  tealDark: '#0A4A5C',
  tealMid: '#126B7A',
  tealBright: '#1B9AAA',
  gold: '#F9C74F',
  goldDark: '#F4A261',
  
  // Background Colors
  bgDark: '#0D1B2A',
  bgCard: '#1B263B',
  bgLight: '#415A77',
  
  // Text Colors
  textPrimary: '#FFFFFF',
  textSecondary: '#B0BEC5',
  textMuted: '#778DA9',
  
  // Status Colors
  success: '#4CAF50',
  error: '#EF5350',
  warning: '#FFA726',
  info: '#29B6F6',
  
  // Trading Colors
  long: '#1B9AAA',
  short: '#F4A261',
  
  // Utility
  border: '#415A77',
  overlay: 'rgba(13, 27, 42, 0.9)',
};

export const GRADIENTS = {
  primary: ['#0A4A5C', '#1B9AAA'],
  gold: ['#F4A261', '#F9C74F'],
  background: ['#0D1B2A', '#1B263B'],
};
