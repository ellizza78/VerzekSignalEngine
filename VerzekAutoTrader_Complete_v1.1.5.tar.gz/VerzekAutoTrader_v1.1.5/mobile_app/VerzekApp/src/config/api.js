// Direct connection to Vultr backend via custom domain
// Vultr VPS at 80.240.29.142 with SSL (api subdomain)
export const API_BASE_URL = 'https://api.verzekinnovative.com';

export const API_ENDPOINTS = {
  REGISTER: '/api/auth/register',
  LOGIN: '/api/auth/login',
  REFRESH: '/api/auth/refresh',
  ME: '/api/auth/me',
  USERS: '/api/users',
  USER_GENERAL: (userId) => `/api/users/${userId}/general`,
  USER_RISK: (userId) => `/api/users/${userId}/risk`,
  USER_STRATEGY: (userId) => `/api/users/${userId}/strategy`,
  USER_DCA: (userId) => `/api/users/${userId}/dca`,
  USER_SUBSCRIPTION: (userId) => `/api/users/${userId}/subscription`,
  USER_EXCHANGES: (userId) => `/api/users/${userId}/exchanges`,
  POSITIONS: '/api/positions',
  USER_POSITIONS: (userId) => `/api/positions/${userId}`,
  SAFETY_STATUS: '/api/safety/status',
};
