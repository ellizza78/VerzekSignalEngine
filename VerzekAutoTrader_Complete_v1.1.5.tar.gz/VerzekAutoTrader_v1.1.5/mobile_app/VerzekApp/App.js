import React, { useState, useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { AuthProvider } from './src/context/AuthContext';
import { RemoteConfigProvider, useRemoteConfig } from './src/context/RemoteConfigContext';
import AppNavigator from './src/navigation/AppNavigator';
import ForceUpdateModal from './src/components/ForceUpdateModal';
import { useAppUpdates } from './src/hooks/useAppUpdates';
import { COLORS } from './src/constants/colors';

function AppContent() {
  const { config, loading: configLoading } = useRemoteConfig();
  const { forceUpdate, updateAvailable, checking } = useAppUpdates(config);

  if (configLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  }

  return (
    <>
      <StatusBar style="light" />
      <AppNavigator />
      
      <ForceUpdateModal
        visible={forceUpdate}
        updateUrl={config?.updateUrl}
        playStoreUrl={config?.playStoreUrl}
      />
    </>
  );
}

export default function App() {
  return (
    <RemoteConfigProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </RemoteConfigProvider>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    backgroundColor: COLORS.background,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
