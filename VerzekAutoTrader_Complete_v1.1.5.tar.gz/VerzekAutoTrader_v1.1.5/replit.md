# VerzekAutoTrader

## Overview
VerzekAutoTrader is a multi-tenant auto-trading platform designed for Dollar Cost Averaging (DCA) strategies. It automates trading by monitoring Telegram signals, broadcasting them to user groups, and executing DCA trades with advanced risk management across multiple exchanges. The platform includes a comprehensive subscription system with tiered access, progressive take-profit, auto-stop logic, and robust user/position management. The project aims to provide a secure, reliable, and automated trading environment with a strong focus on user experience and to enable users to participate in automated trading with sophisticated strategies.

## User Preferences
- **Production Safety**: Enterprise-grade database with ACID compliance required
- **Security First**: No hard-coded secrets, all environment variables mandatory
- **Trade Capacity**: Default 50 concurrent positions per user (configurable)
- **Build Process**: ALWAYS build Android APK from Replit Shell using `eas build` command (never use automated tools)
- **Dynamic Updates**: Use OTA updates (eas update) for JavaScript changes; remote config for feature flags and settings; only rebuild APK for native changes

## Production URLs
- **Backend API**: https://verzekinnovative.com (Vultr VPS: 80.240.29.142)
- **Email Service**: support@verzekinnovative.com (Resend API verified domain)
- **Legacy Bridge** (deprecated): https://verzek-auto-trader.replit.app (no longer used in production)

## Recent Changes (November 2025)
- **Production Deployment**: Backend successfully deployed to Vultr VPS with Nginx reverse proxy and Let's Encrypt SSL
- **Health Endpoint**: Added `/api/health` endpoint for monitoring and load balancer health checks
- **Port Configuration**: Backend runs on port 8000 (changed from 5000), proxied through Nginx on port 443
- **Email Service**: Resend API fully integrated with support@verzekinnovative.com as verified sender
- **Environment Setup**: All secrets stored in `/root/api_server_env.sh` with proper permissions (chmod 600)
- **Security**: Fernet encryption key securely stored in environment variables (ENCRYPTION_MASTER_KEY)

## System Architecture
### UI/UX Decisions
The mobile application (React Native + Expo) utilizes a modern dark theme with Teal/Gold gradients. It features an onboarding modal and a compact UI for optimal content visibility.

### Technical Implementations
- **Core Trading Modules**: Includes a DCA Engine, Safety Manager, DCA Orchestrator, and a Position Tracker with target-based take-profit.
- **Multi-User Management**: Supports multi-tenancy with per-user configurations, risk settings, exchange account management, symbol whitelists/blacklists, and subscription plans.
- **Exchange Adapters**: A unified interface supports Binance, Bybit, Phemex, and Kraken, offering both live and demo trading modes with secure API key handling.
- **Static IP Proxy Infrastructure**: A Vultr-based WireGuard VPN mesh with HAProxy and Nginx routes all exchange API calls through a static IP (45.76.90.149) for IP whitelisting, featuring HMAC SHA256 authentication and automatic failover.
- **Signal Broadcasting System**: Monitors Telegram for signals with keyword detection and spam filtering, distributing them to VIP/TRIAL Telegram groups and a protected API endpoint for the mobile app.
- **REST API Server (Flask)**: Provides JWT-authenticated endpoints for managing users, settings, subscriptions, exchange accounts, and positions, incorporating rate limiting, 2FA, and audit logging.
- **Mobile Application (React Native + Expo)**: Features JWT authentication, secure storage, a dashboard for account overview, API integration with the Flask backend, auth-based navigation, and comprehensive help resources.
- **Security & Payments**: Multi-layer security with JWT authentication, server-side subscription validation, USDT TRC20 payment processing, automatic referral bonuses, HMAC signature verification, custom CAPTCHA, and email verification. API keys are encrypted at rest.
- **Email Verification System**: Secure token-based email verification with Resend API (support@verzekinnovative.com), required before users can connect exchange accounts or trade.
- **Advanced Features**: Includes an AI Trade Assistant (GPT-4o-mini), Multi-Timeframe Analysis, Smart Order Routing, Social Trading, Advanced Charting, ML-powered Auto-Optimization, AI Risk Scoring, Trading Journal, Real-Time Price Feed (WebSockets), Portfolio Rebalancing, Webhook Integration, Advanced Order Types, Push Notifications (FCM), Admin Dashboard, Automated Backups, and TronScan Integration.
- **Health Monitoring System**: Deployed with heartbeat monitoring, watchdog auto-restart, and Telegram admin alerts for continuous operation and quick recovery from service interruptions.
- **Dynamic Update Architecture**: Remote config system enables instant updates without APK rebuilds. Features include: remote config endpoint (/api/app-config), feature flags for A/B testing, OTA updates via Expo EAS Update, force update flow for mandatory upgrades, and auto-refresh every 5 minutes. Config stored in SQLite with admin CLI tool for management.

### System Design Choices
- **Multi-tenancy**: Isolated configurations and strategies per user.
- **Microservices-like Components**: Separation of concerns into distinct modules.
- **Production Database**: SQLite with ACID compliance, WAL mode, and concurrent write safety.
- **Environment Variables**: All sensitive information is stored in environment variables.
- **24/7 Operation**: Designed for continuous uptime.
- **Subscription Model**: Tiered access (FREE/TRIAL, VIP, PREMIUM) with varying features.
- **Authentication**: JWT-based with secure password hashing and token refresh.
- **Encryption**: Fernet (AES-128 CBC mode) for API keys, with master key stored in Replit Secrets.

## External Dependencies
- **Telegram API**: For signal monitoring and broadcasting.
- **Binance API**: For trading operations.
- **Bybit API**: For trading operations.
- **Phemex API**: For trading operations.
- **Kraken Futures API**: For trading operations.
- **Flask**: Python web framework.
- **Requests**: Python HTTP library.
- **Schedule**: Python library for task scheduling.
- **PyJWT**: For JWT authentication.
- **Bcrypt**: For password hashing.
- **OpenAI API**: For AI Trade Assistant (GPT-4o-mini).
- **Firebase Cloud Messaging (FCM)**: For push notifications.
- **TronScan API**: For USDT TRC20 payment verification.
- **Resend API**: For transactional emails (support@verzekinnovative.com verified domain).